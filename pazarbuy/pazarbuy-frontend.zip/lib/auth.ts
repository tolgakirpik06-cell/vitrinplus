export const AUTH_DIRECTORY_KEY = "pazarbuy-auth-directory";
export const AUTH_SESSION_KEY = "pazarbuy-auth-session";

export function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

/** Türkiye telefon numarası — 10 veya 11 haneli (başında 0 olsun olmasın). */
export function isValidPhone(value: string): boolean {
  const digits = value.replace(/\D/g, "");
  return digits.length === 10 || digits.length === 11;
}

/** Kullanıcı yazarken görüntü formatı: 05xx xxx xx xx */
export function formatPhoneInput(value: string): string {
  let digits = value.replace(/\D/g, "").slice(0, 11);
  if (digits.length > 0 && digits[0] !== "0") digits = "0" + digits;
  digits = digits.slice(0, 11);

  const parts = [digits.slice(0, 4), digits.slice(4, 7), digits.slice(7, 9), digits.slice(9, 11)].filter(
    Boolean
  );
  return parts.join(" ");
}

/** Backend'e/karşılaştırmaya gönderilecek normalize edilmiş biçim: 5xxxxxxxxx (10 hane, başında 0 yok). */
export function normalizePhone(value: string): string {
  const digits = value.replace(/\D/g, "");
  return digits.length === 11 && digits[0] === "0" ? digits.slice(1) : digits;
}

export type PasswordStrength = "zayif" | "orta" | "guclu";

export function getPasswordStrength(value: string): PasswordStrength {
  let score = 0;
  if (value.length >= 8) score++;
  if (value.length >= 12) score++;
  if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
  if (/\d/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;

  if (score >= 4) return "guclu";
  if (score >= 2) return "orta";
  return "zayif";
}

export function isValidPassword(value: string): boolean {
  return value.length >= 8;
}

/**
 * Şifreyi hiçbir zaman düz metin olarak saklamamak için SHA-256 hash'i.
 * ÖNEMLİ: Bu, gerçek bir backend'in yapması gereken (bcrypt/argon2 + salt +
 * sunucu tarafı) şifreleme YERİNE GEÇMEZ — Web Crypto API ile istemci
 * tarafında hesaplanan bu hash sadece "localStorage'a düz metin şifre
 * yazma" kısıtını sağlamak için bir demo/mock önlemidir. Gerçek backend
 * bağlandığında şifre asla client'ta hash'lenmemeli, HTTPS üzerinden
 * sunucuya gönderilip orada işlenmelidir.
 */
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function generateUserId(): string {
  return `u_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
