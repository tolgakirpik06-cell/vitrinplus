export function addressesStorageKey(userId: string) {
  return `pazarbuy-addresses:${userId}`;
}

export function reviewsStorageKey(userId: string) {
  return `pazarbuy-reviews:${userId}`;
}

export function notificationPrefsStorageKey(userId: string) {
  return `pazarbuy-notification-prefs:${userId}`;
}

export function generateId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

export function formatOrderDate(iso: string): string {
  return new Date(iso).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
}
