/**
 * Müşteri üyelik / kimlik doğrulama sistemi için tip tanımları.
 * Gerçek bir backend/API YOK — bu turda tamamen frontend'de, localStorage
 * tabanlı bir MOCK adapter ile çalışır (bkz. lib/auth.ts). Fonksiyon
 * imzaları (login/register/logout Promise döndürüyor) gerçek bir API'ye
 * bağlanmaya hazır şekilde tasarlandı; gerçek backend geldiğinde sadece
 * AuthProvider içindeki mock adapter'ın gövdesi değişmeli, çağıran
 * component'lerin hiçbiri değişmemeli.
 */

export type AuthUser = {
  id: string;
  ad: string;
  soyad: string;
  email: string;
  telefon: string;
  createdAt: string;
};

export type RegisterInput = {
  ad: string;
  soyad: string;
  email: string;
  telefon: string;
  sifre: string;
  sifreTekrar: string;
  uyelikSozlesmesiKabul: boolean;
  kvkkKabul: boolean;
  ticariIletiKabul: boolean;
};

export type LoginInput = {
  identifier: string; // e-posta veya telefon
  sifre: string;
  beniHatirla: boolean;
};

export type AuthResult = { ok: true } | { ok: false; error: string };

export type ProfileUpdateInput = Partial<Pick<AuthUser, "ad" | "soyad" | "email" | "telefon">>;

export type PasswordChangeInput = {
  mevcutSifre: string;
  yeniSifre: string;
  yeniSifreTekrar: string;
};

export type PasswordResetInput = {
  identifier: string; // e-posta veya telefon
  yeniSifre: string;
  yeniSifreTekrar: string;
};
