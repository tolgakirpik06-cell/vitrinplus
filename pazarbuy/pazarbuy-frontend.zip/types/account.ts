/**
 * Müşteri hesap paneli (/hesabim) için tip tanımları. Gerçek bir backend
 * YOK — siparişler/kuponlar sabit mock veri (data/account-mock.ts),
 * adresler/bildirim tercihleri/değerlendirmeler ise kullanıcının
 * tarayıcısında localStorage'da tutulan gerçek (düzenlenebilir) state.
 */

export type OrderStatus =
  | "alindi"
  | "hazirlaniyor"
  | "kargoda"
  | "teslim-edildi"
  | "iptal-edildi"
  | "iade-surecinde"
  | "iade-edildi";

export const orderStatusLabels: Record<OrderStatus, string> = {
  alindi: "Sipariş Alındı",
  hazirlaniyor: "Hazırlanıyor",
  kargoda: "Kargoya Verildi",
  "teslim-edildi": "Teslim Edildi",
  "iptal-edildi": "İptal Edildi",
  "iade-surecinde": "İade Sürecinde",
  "iade-edildi": "İade Edildi",
};

export type OrderItem = {
  slug: string;
  quantity: number;
  priceAtPurchase: number;
};

export type Order = {
  id: string;
  orderNumber: string;
  date: string;
  seller: string;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
};

export type CouponStatus = "kullanilabilir" | "kullanildi" | "suresi-dolmus";

export type Coupon = {
  id: string;
  code: string;
  discountLabel: string;
  minCartLabel?: string;
  validUntil: string;
  scope: string;
  status: CouponStatus;
};

export type AddressType = "ev" | "is" | "diger";

export type Address = {
  id: string;
  title: string;
  ad: string;
  soyad: string;
  telefon: string;
  il: string;
  ilce: string;
  mahalle: string;
  acikAdres: string;
  postaKodu?: string;
  type: AddressType;
  isDefault: boolean;
};

export type Review = {
  id: string;
  orderId: string;
  slug: string;
  rating: number;
  comment: string;
  photos: { name: string; size: number; type: string }[];
  createdAt: string;
};

export type NotificationChannel = "email" | "sms" | "push";

export type NotificationPreferences = {
  orders: Record<NotificationChannel, boolean>;
  campaigns: Record<NotificationChannel, boolean>;
};

export const defaultNotificationPreferences: NotificationPreferences = {
  orders: { email: true, sms: true, push: false },
  campaigns: { email: false, sms: false, push: false },
};
