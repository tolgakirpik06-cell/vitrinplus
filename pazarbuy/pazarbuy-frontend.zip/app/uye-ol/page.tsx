import { redirect } from "next/navigation";

export default async function UyeOlRedirect({
  searchParams,
}: {
  searchParams: Promise<{ redirect?: string }>;
}) {
  const params = await searchParams;
  const redirectTo = params.redirect;
  redirect(redirectTo ? `/kayit?redirect=${encodeURIComponent(redirectTo)}` : "/kayit");
}
