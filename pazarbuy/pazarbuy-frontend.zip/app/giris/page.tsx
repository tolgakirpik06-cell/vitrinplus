import type { Metadata } from "next";
import { Suspense } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { GirisPageClient } from "@/components/auth/GirisPageClient";

export const metadata: Metadata = { title: "Giriş Yap | PazarBuy" };

export default function GirisPage() {
  return (
    <>
      <Header />

      <main className="section-container flex flex-col gap-6 py-10 sm:py-14">
        <Breadcrumb items={[{ label: "Ana Sayfa", href: "/" }, { label: "Giriş Yap" }]} />

        <Suspense fallback={null}>
          <GirisPageClient />
        </Suspense>
      </main>

      <Footer />
    </>
  );
}
