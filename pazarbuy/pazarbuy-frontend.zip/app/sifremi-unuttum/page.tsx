import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { SifremiUnuttumPageClient } from "@/components/auth/SifremiUnuttumPageClient";

export const metadata: Metadata = { title: "Şifremi Unuttum | PazarBuy" };

export default function SifremiUnuttumPage() {
  return (
    <>
      <Header />

      <main className="section-container flex flex-col gap-6 py-10 sm:py-14">
        <Breadcrumb items={[{ label: "Ana Sayfa", href: "/" }, { label: "Şifremi Unuttum" }]} />

        <SifremiUnuttumPageClient />
      </main>

      <Footer />
    </>
  );
}
