import type { Metadata } from "next";
import { Suspense } from "react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { DogrulamaPageClient } from "@/components/auth/DogrulamaPageClient";

export const metadata: Metadata = { title: "Hesap Doğrulama | PazarBuy" };

export default function DogrulamaPage() {
  return (
    <>
      <Header />

      <main className="section-container flex flex-col gap-6 py-10 sm:py-14">
        <Breadcrumb items={[{ label: "Ana Sayfa", href: "/" }, { label: "Doğrulama" }]} />

        <Suspense fallback={null}>
          <DogrulamaPageClient />
        </Suspense>
      </main>

      <Footer />
    </>
  );
}
