import type { Metadata } from "next";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { AccountShell } from "@/components/account/AccountShell";

export const metadata: Metadata = { title: "Hesabım | PazarBuy" };

export default function HesabimLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />

      <main className="section-container flex flex-col gap-5 py-6 sm:py-8">
        <Breadcrumb items={[{ label: "Ana Sayfa", href: "/" }, { label: "Hesabım" }]} />
        <AccountShell>{children}</AccountShell>
      </main>

      <Footer />
    </>
  );
}
