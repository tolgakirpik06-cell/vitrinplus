"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import {
  ChevronDown,
  Package,
  RotateCcw,
  Star,
  Truck,
  Undo2,
} from "lucide-react";
import { mockOrders } from "@/data/account-mock";
import { getProductBySlug } from "@/lib/mock-catalog";
import { useCart } from "@/components/cart/CartProvider";
import { formatOrderDate } from "@/lib/account";
import { orderStatusLabels } from "@/types/account";
import type { Order, OrderStatus } from "@/types/account";
import { formatPrice, cn } from "@/lib/utils";

const TRACKING_STEPS: OrderStatus[] = ["alindi", "hazirlaniyor", "kargoda", "teslim-edildi"];

const statusToneClass: Record<OrderStatus, string> = {
  alindi: "bg-sky-50 text-sky-700",
  hazirlaniyor: "bg-amber-50 text-amber-700",
  kargoda: "bg-brand-50 text-brand-700",
  "teslim-edildi": "bg-emerald-50 text-emerald-700",
  "iptal-edildi": "bg-navy-100 text-navy-500",
  "iade-surecinde": "bg-rose-50 text-rose-700",
  "iade-edildi": "bg-navy-100 text-navy-500",
};

export default function SiparislerimPage() {
  const { addItem } = useCart();
  const [statusOverrides, setStatusOverrides] = useState<Record<string, OrderStatus>>({});
  const [expanded, setExpanded] = useState<Record<string, "detay" | "kargo" | null>>({});
  const [returnRequested, setReturnRequested] = useState<Record<string, boolean>>({});
  const [reorderedId, setReorderedId] = useState<string | null>(null);

  const orders = useMemo(
    () => mockOrders.map((order) => ({ ...order, status: statusOverrides[order.id] ?? order.status })),
    [statusOverrides]
  );

  function toggle(orderId: string, panel: "detay" | "kargo") {
    setExpanded((prev) => ({ ...prev, [orderId]: prev[orderId] === panel ? null : panel }));
  }

  function handleReturnRequest(order: Order) {
    setStatusOverrides((prev) => ({ ...prev, [order.id]: "iade-surecinde" }));
    setReturnRequested((prev) => ({ ...prev, [order.id]: true }));
  }

  function handleReorder(order: Order) {
    order.items.forEach((item) => addItem({ slug: item.slug, quantity: item.quantity }));
    setReorderedId(order.id);
    window.setTimeout(() => setReorderedId(null), 2500);
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Siparişlerim</h1>
        <p className="mt-1 text-sm text-navy-400">{orders.length} sipariş bulundu</p>
      </div>

      {orders.map((order) => {
        const resolvedItems = order.items
          .map((item) => ({ item, product: getProductBySlug(item.slug) }))
          .filter((x) => Boolean(x.product));
        const canTrack = order.status === "alindi" || order.status === "hazirlaniyor" || order.status === "kargoda";
        const canReturn = order.status === "teslim-edildi" && !returnRequested[order.id];
        const canReview = order.status === "teslim-edildi";
        const canReorder = order.status === "teslim-edildi" || order.status === "iptal-edildi";
        const panel = expanded[order.id] ?? null;

        return (
          <div key={order.id} className="rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-navy-50 pb-3">
              <div>
                <p className="text-sm font-bold text-navy-900">{order.orderNumber}</p>
                <p className="mt-0.5 text-xs text-navy-400">
                  {formatOrderDate(order.date)} · {order.seller}
                </p>
              </div>
              <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold", statusToneClass[order.status])}>
                {orderStatusLabels[order.status]}
              </span>
            </div>

            <div className="mt-3 flex flex-col gap-2.5">
              {resolvedItems.map(({ item, product }) =>
                product ? (
                  <div key={item.slug} className="flex items-center justify-between gap-2 text-sm">
                    <Link href={`/urun/${product.slug}`} className="min-w-0 flex-1 truncate text-navy-700 hover:text-brand-600">
                      {product.name} <span className="text-navy-300">x{item.quantity}</span>
                    </Link>
                    <span className="shrink-0 font-semibold text-navy-800">
                      {formatPrice(item.priceAtPurchase * item.quantity)}
                    </span>
                  </div>
                ) : null
              )}
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-navy-50 pt-3">
              <span className="text-xs text-navy-400">Toplam</span>
              <span className="text-sm font-extrabold text-navy-900">{formatPrice(order.total)}</span>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => toggle(order.id, "detay")}
                className="flex items-center gap-1.5 rounded-full border border-navy-100 px-3.5 py-1.5 text-xs font-semibold text-navy-600 hover:border-navy-300"
              >
                <Package size={13} />
                Sipariş Detayı
                <ChevronDown size={12} className={cn("transition-transform", panel === "detay" && "rotate-180")} />
              </button>

              {canTrack ? (
                <button
                  type="button"
                  onClick={() => toggle(order.id, "kargo")}
                  className="flex items-center gap-1.5 rounded-full border border-navy-100 px-3.5 py-1.5 text-xs font-semibold text-navy-600 hover:border-navy-300"
                >
                  <Truck size={13} />
                  Kargoyu Takip Et
                  <ChevronDown size={12} className={cn("transition-transform", panel === "kargo" && "rotate-180")} />
                </button>
              ) : null}

              {canReturn ? (
                <button
                  type="button"
                  onClick={() => handleReturnRequest(order)}
                  className="flex items-center gap-1.5 rounded-full border border-navy-100 px-3.5 py-1.5 text-xs font-semibold text-navy-600 hover:border-rose-300 hover:text-rose-600"
                >
                  <Undo2 size={13} />
                  İade Talebi
                </button>
              ) : null}

              {canReview ? (
                <Link
                  href="/hesabim/degerlendirmelerim"
                  className="flex items-center gap-1.5 rounded-full border border-navy-100 px-3.5 py-1.5 text-xs font-semibold text-navy-600 hover:border-amber-300 hover:text-amber-600"
                >
                  <Star size={13} />
                  Değerlendir
                </Link>
              ) : null}

              {canReorder ? (
                <button
                  type="button"
                  onClick={() => handleReorder(order)}
                  className="flex items-center gap-1.5 rounded-full bg-brand-50 px-3.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                >
                  <RotateCcw size={13} />
                  {reorderedId === order.id ? "Sepete Eklendi" : "Tekrar Satın Al"}
                </button>
              ) : null}
            </div>

            {panel === "detay" ? (
              <div className="mt-3 rounded-xl bg-navy-50/50 p-3.5 text-xs text-navy-500">
                <p>Satıcı: <span className="font-semibold text-navy-700">{order.seller}</span></p>
                <p className="mt-1">Sipariş Tarihi: <span className="font-semibold text-navy-700">{formatOrderDate(order.date)}</span></p>
                <p className="mt-1">Ürün Sayısı: <span className="font-semibold text-navy-700">{order.items.reduce((s, i) => s + i.quantity, 0)}</span></p>
              </div>
            ) : null}

            {panel === "kargo" ? (
              <div className="mt-3 flex items-center justify-between rounded-xl bg-navy-50/50 p-3.5">
                {TRACKING_STEPS.map((step, index) => {
                  const currentIndex = TRACKING_STEPS.indexOf(order.status);
                  const done = index <= currentIndex;
                  return (
                    <div key={step} className="flex flex-1 flex-col items-center gap-1.5 text-center">
                      <span
                        className={cn(
                          "flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold",
                          done ? "bg-brand-500 text-white" : "bg-navy-100 text-navy-400"
                        )}
                      >
                        {index + 1}
                      </span>
                      <span className={cn("text-[10px] font-medium", done ? "text-navy-700" : "text-navy-400")}>
                        {orderStatusLabels[step]}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : null}

            {returnRequested[order.id] ? (
              <p className="mt-3 text-[11px] text-navy-400">
                İade talebiniz oluşturuldu (demo — gerçek bir iade süreci başlatılmaz).
              </p>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
