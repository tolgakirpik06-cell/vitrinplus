"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Camera, Star, X } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { mockOrders } from "@/data/account-mock";
import { getProductBySlug } from "@/lib/mock-catalog";
import { reviewsStorageKey, generateId, formatOrderDate } from "@/lib/account";
import { TextareaField } from "@/components/seller-application/fields";
import type { Review } from "@/types/account";
import { cn } from "@/lib/utils";

type PendingItem = { orderId: string; orderDate: string; slug: string };
type Tab = "bekleyen" | "degerlendirdiklerim";

function readReviews(userId: string): Review[] {
  try {
    const raw = window.localStorage.getItem(reviewsStorageKey(userId));
    const parsed = raw ? (JSON.parse(raw) as Review[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function DegerlendirmelerimPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<Tab>("bekleyen");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [activeForm, setActiveForm] = useState<PendingItem | null>(null);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [photos, setPhotos] = useState<{ name: string; size: number; type: string }[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    setReviews(readReviews(user.id));
    setHydrated(true);
  }, [user]);

  useEffect(() => {
    if (!user || !hydrated) return;
    try {
      window.localStorage.setItem(reviewsStorageKey(user.id), JSON.stringify(reviews));
    } catch {
      // best-effort
    }
  }, [reviews, user, hydrated]);

  const deliveredItems: PendingItem[] = useMemo(() => {
    const items: PendingItem[] = [];
    for (const order of mockOrders) {
      if (order.status !== "teslim-edildi") continue;
      for (const item of order.items) {
        items.push({ orderId: order.id, orderDate: order.date, slug: item.slug });
      }
    }
    return items;
  }, []);

  const reviewedKeys = useMemo(() => new Set(reviews.map((r) => `${r.orderId}::${r.slug}`)), [reviews]);
  const pendingItems = deliveredItems.filter((item) => !reviewedKeys.has(`${item.orderId}::${item.slug}`));

  if (!user) return null;

  function openForm(item: PendingItem) {
    setActiveForm(item);
    setRating(0);
    setComment("");
    setPhotos([]);
    setError(null);
  }

  function closeForm() {
    setActiveForm(null);
  }

  function handlePhotoSelect(fileList: FileList | null) {
    if (!fileList) return;
    const next = Array.from(fileList)
      .slice(0, 4 - photos.length)
      .map((file) => ({ name: file.name, size: file.size, type: file.type || "bilinmiyor" }));
    setPhotos((prev) => [...prev, ...next].slice(0, 4));
  }

  function handleSubmit() {
    if (!activeForm) return;
    if (rating === 0) {
      setError("Lütfen bir puan seçin.");
      return;
    }
    if (!comment.trim()) {
      setError("Lütfen bir yorum yazın.");
      return;
    }

    const review: Review = {
      id: generateId("rev"),
      orderId: activeForm.orderId,
      slug: activeForm.slug,
      rating,
      comment: comment.trim(),
      photos,
      createdAt: new Date().toISOString(),
    };
    setReviews((prev) => [review, ...prev]);
    closeForm();
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Değerlendirmelerim</h1>
        <p className="mt-1 text-sm text-navy-400">Teslim edilen ürünleri değerlendirebilirsin.</p>
      </div>

      <div className="flex gap-1.5 overflow-x-auto">
        <button
          type="button"
          onClick={() => setTab("bekleyen")}
          className={cn(
            "shrink-0 rounded-full border px-4 py-2 text-xs font-semibold transition-colors",
            tab === "bekleyen" ? "border-brand-500 bg-brand-500 text-white" : "border-navy-100 bg-white text-navy-600"
          )}
        >
          Değerlendirme Bekleyen ({pendingItems.length})
        </button>
        <button
          type="button"
          onClick={() => setTab("degerlendirdiklerim")}
          className={cn(
            "shrink-0 rounded-full border px-4 py-2 text-xs font-semibold transition-colors",
            tab === "degerlendirdiklerim"
              ? "border-brand-500 bg-brand-500 text-white"
              : "border-navy-100 bg-white text-navy-600"
          )}
        >
          Değerlendirdiklerim ({reviews.length})
        </button>
      </div>

      {tab === "bekleyen" ? (
        pendingItems.length === 0 ? (
          <EmptyState text="Değerlendirme bekleyen ürünün yok." />
        ) : (
          <div className="flex flex-col gap-3">
            {pendingItems.map((item) => {
              const product = getProductBySlug(item.slug);
              if (!product) return null;
              const isOpen = activeForm?.orderId === item.orderId && activeForm?.slug === item.slug;
              return (
                <div key={`${item.orderId}-${item.slug}`} className="rounded-2xl border border-navy-100/80 bg-white p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <Link href={`/urun/${product.slug}`} className="truncate text-sm font-semibold text-navy-800 hover:text-brand-600">
                        {product.name}
                      </Link>
                      <p className="mt-0.5 text-xs text-navy-400">Teslim tarihi: {formatOrderDate(item.orderDate)}</p>
                    </div>
                    {!isOpen ? (
                      <button
                        type="button"
                        onClick={() => openForm(item)}
                        className="shrink-0 rounded-full bg-brand-50 px-3.5 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
                      >
                        Değerlendir
                      </button>
                    ) : null}
                  </div>

                  {isOpen ? (
                    <div className="mt-3 flex flex-col gap-3 border-t border-navy-50 pt-3.5">
                      <div className="flex items-center gap-1.5">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button key={star} type="button" onClick={() => setRating(star)} aria-label={`${star} yıldız`}>
                            <Star
                              size={22}
                              className={star <= rating ? "fill-amber-400 text-amber-400" : "text-navy-200"}
                            />
                          </button>
                        ))}
                      </div>

                      <TextareaField
                        label="Yorumun"
                        id={`comment-${item.slug}`}
                        placeholder="Ürün hakkındaki deneyimini paylaş..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                      />

                      <div className="flex flex-col gap-1.5">
                        <p className="text-sm font-semibold text-navy-800">Fotoğraf Ekle (opsiyonel)</p>
                        <div className="flex flex-wrap items-center gap-2">
                          {photos.map((photo, index) => (
                            <span
                              key={`${photo.name}-${index}`}
                              className="flex items-center gap-1.5 rounded-full bg-navy-50 py-1.5 pl-3 pr-1.5 text-[11px] font-medium text-navy-600"
                            >
                              {photo.name}
                              <button
                                type="button"
                                onClick={() => setPhotos((prev) => prev.filter((_, i) => i !== index))}
                                className="flex h-4 w-4 items-center justify-center rounded-full hover:bg-navy-200"
                              >
                                <X size={10} />
                              </button>
                            </span>
                          ))}
                          {photos.length < 4 ? (
                            <label className="flex cursor-pointer items-center gap-1.5 rounded-full border border-dashed border-navy-200 px-3 py-1.5 text-[11px] font-medium text-navy-500 hover:border-brand-300 hover:text-brand-600">
                              <Camera size={13} />
                              Fotoğraf Seç
                              <input
                                type="file"
                                accept="image/*"
                                multiple
                                className="hidden"
                                onChange={(e) => handlePhotoSelect(e.target.files)}
                              />
                            </label>
                          ) : null}
                        </div>
                      </div>

                      {error ? <p className="text-xs font-medium text-rose-600">{error}</p> : null}

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleSubmit}
                          className="rounded-full bg-brand-500 px-5 py-2 text-xs font-semibold text-white hover:bg-brand-600"
                        >
                          Değerlendirmeyi Gönder
                        </button>
                        <button
                          type="button"
                          onClick={closeForm}
                          className="rounded-full border border-navy-100 px-5 py-2 text-xs font-semibold text-navy-600 hover:border-navy-300"
                        >
                          Vazgeç
                        </button>
                      </div>
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )
      ) : reviews.length === 0 ? (
        <EmptyState text="Henüz bir değerlendirme yapmadın." />
      ) : (
        <div className="flex flex-col gap-3">
          {reviews.map((review) => {
            const product = getProductBySlug(review.slug);
            return (
              <div key={review.id} className="rounded-2xl border border-navy-100/80 bg-white p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="truncate text-sm font-semibold text-navy-800">{product?.name ?? review.slug}</p>
                  <div className="flex shrink-0 items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} size={13} className={star <= review.rating ? "fill-amber-400 text-amber-400" : "text-navy-200"} />
                    ))}
                  </div>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-navy-500">{review.comment}</p>
                {review.photos.length > 0 ? (
                  <p className="mt-1.5 text-[11px] text-navy-400">{review.photos.length} fotoğraf eklendi</p>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-navy-100/80 bg-white px-6 py-14 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-50 text-amber-500">
        <Star size={24} />
      </span>
      <p className="text-sm font-semibold text-navy-800">{text}</p>
    </div>
  );
}
