"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, LogOut, MonitorSmartphone, ShieldCheck } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { PasswordField } from "@/components/auth/PasswordField";

export default function GuvenlikPage() {
  const { changePassword, logout } = useAuth();
  const router = useRouter();
  const [mevcutSifre, setMevcutSifre] = useState("");
  const [yeniSifre, setYeniSifre] = useState("");
  const [yeniSifreTekrar, setYeniSifreTekrar] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    setError(null);
    setSuccess(false);
    if (!mevcutSifre) {
      setError("Mevcut şifreni girmelisin.");
      return;
    }
    if (yeniSifre.length < 8) {
      setError("Yeni şifre en az 8 karakter olmalı.");
      return;
    }
    if (yeniSifre !== yeniSifreTekrar) {
      setError("Yeni şifreler eşleşmiyor.");
      return;
    }

    setSubmitting(true);
    const result = await changePassword({ mevcutSifre, yeniSifre, yeniSifreTekrar });
    setSubmitting(false);

    if (!result.ok) {
      setError(result.error);
      return;
    }
    setMevcutSifre("");
    setYeniSifre("");
    setYeniSifreTekrar("");
    setSuccess(true);
    window.setTimeout(() => setSuccess(false), 2500);
  }

  function handleLogout() {
    logout();
    router.push("/");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Güvenlik</h1>
        <p className="mt-1 text-sm text-navy-400">Şifreni değiştir ve hesap güvenliğini yönet.</p>
      </div>

      <div className="max-w-lg rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
            <ShieldCheck size={16} />
          </span>
          <p className="text-sm font-bold text-navy-900">Şifre Değiştir</p>
        </div>

        <div className="mt-3.5 flex flex-col gap-3.5">
          <PasswordField
            id="mevcut-sifre"
            label="Mevcut Şifre"
            value={mevcutSifre}
            onChange={setMevcutSifre}
            autoComplete="current-password"
            required
          />
          <PasswordField
            id="yeni-sifre"
            label="Yeni Şifre"
            value={yeniSifre}
            onChange={setYeniSifre}
            autoComplete="new-password"
            showStrength
            hint="En az 8 karakter — büyük/küçük harf ve rakam kullanman önerilir."
            required
          />
          <PasswordField
            id="yeni-sifre-tekrar"
            label="Yeni Şifre (Tekrar)"
            value={yeniSifreTekrar}
            onChange={setYeniSifreTekrar}
            autoComplete="new-password"
            required
          />
        </div>

        {error ? <p className="mt-3 text-xs font-medium text-rose-600">{error}</p> : null}

        <div className="mt-4 flex items-center gap-3">
          <button
            type="button"
            onClick={handleSubmit}
            disabled={submitting}
            className="rounded-full bg-brand-500 px-5 py-2.5 text-xs font-semibold text-white hover:bg-brand-600 disabled:opacity-60"
          >
            {submitting ? "Kaydediliyor…" : "Şifreyi Güncelle"}
          </button>
          {success ? (
            <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
              <CheckCircle2 size={14} />
              Şifren güncellendi
            </span>
          ) : null}
        </div>
      </div>

      <div className="max-w-lg rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-navy-50 text-navy-500">
            <MonitorSmartphone size={16} />
          </span>
          <div>
            <p className="text-sm font-bold text-navy-900">Aktif Oturumlar</p>
            <p className="text-[11px] text-navy-400">Bu özellik yakında eklenecek.</p>
          </div>
        </div>
        <p className="mt-3 text-xs text-navy-400">
          Gelecekte buradan hesabına giriş yapılan cihazları görebilecek ve dilediğin oturumu (veya tüm
          cihazlardan çıkışı) buradan sonlandırabileceksin.
        </p>
      </div>

      <div className="max-w-lg rounded-2xl border border-rose-200/70 bg-rose-50/40 p-4 sm:p-5">
        <p className="text-sm font-bold text-navy-900">Hesaptan Çıkış</p>
        <p className="mt-1 text-xs text-navy-400">Bu cihazdaki oturumunu sonlandırır.</p>
        <button
          type="button"
          onClick={handleLogout}
          className="mt-3 flex items-center gap-1.5 rounded-full bg-rose-600 px-4 py-2 text-xs font-semibold text-white hover:bg-rose-700"
        >
          <LogOut size={14} />
          Çıkış Yap
        </button>
      </div>
    </div>
  );
}
