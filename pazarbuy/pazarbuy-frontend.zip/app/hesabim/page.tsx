"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ClipboardList, Heart, MapPin, Ticket, ArrowRight } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { useFavorites } from "@/components/favorites/FavoritesProvider";
import { mockCoupons, mockOrders } from "@/data/account-mock";
import { addressesStorageKey, formatOrderDate } from "@/lib/account";
import { orderStatusLabels } from "@/types/account";
import type { Address } from "@/types/account";
import { products } from "@/data/products";
import { ProductCard } from "@/components/home/ProductCard";
import { formatPrice } from "@/lib/utils";

const ACTIVE_STATUSES = new Set(["alindi", "hazirlaniyor", "kargoda", "iade-surecinde"]);

export default function HesabimOzetPage() {
  const { user } = useAuth();
  const { slugs: favoriteSlugs } = useFavorites();
  const [addressCount, setAddressCount] = useState(0);

  useEffect(() => {
    if (!user) return;
    try {
      const raw = window.localStorage.getItem(addressesStorageKey(user.id));
      const parsed = raw ? (JSON.parse(raw) as Address[]) : [];
      setAddressCount(Array.isArray(parsed) ? parsed.length : 0);
    } catch {
      setAddressCount(0);
    }
  }, [user]);

  const activeOrders = useMemo(() => mockOrders.filter((o) => ACTIVE_STATUSES.has(o.status)), []);
  const availableCoupons = useMemo(() => mockCoupons.filter((c) => c.status === "kullanilabilir"), []);
  const lastOrder = mockOrders[0];
  const suggestions = products.slice(0, 4);

  if (!user) return null;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Merhaba, {user.ad}</h1>
        <p className="mt-1 text-sm text-navy-400">Hesabına ve siparişlerine buradan hızlıca göz atabilirsin.</p>
      </div>

      <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-4">
        <SummaryCard icon={ClipboardList} label="Aktif Sipariş" value={activeOrders.length} href="/hesabim/siparislerim" />
        <SummaryCard icon={Heart} label="Favori Ürün" value={favoriteSlugs.length} href="/hesabim/favorilerim" />
        <SummaryCard icon={MapPin} label="Kayıtlı Adres" value={addressCount} href="/hesabim/adreslerim" />
        <SummaryCard icon={Ticket} label="Kullanılabilir Kupon" value={availableCoupons.length} href="/hesabim/kuponlarim" />
      </div>

      {lastOrder ? (
        <div className="rounded-2xl border border-navy-100/80 bg-white p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-navy-900">Son Siparişin</h2>
            <Link href="/hesabim/siparislerim" className="text-xs font-semibold text-brand-600 hover:text-brand-700">
              Tüm Siparişler
            </Link>
          </div>
          <div className="mt-3 flex items-center justify-between gap-3 text-sm">
            <div>
              <p className="font-semibold text-navy-800">{lastOrder.orderNumber}</p>
              <p className="mt-0.5 text-xs text-navy-400">{formatOrderDate(lastOrder.date)}</p>
            </div>
            <div className="text-right">
              <p className="font-bold text-navy-900">{formatPrice(lastOrder.total)}</p>
              <p className="mt-0.5 text-xs font-medium text-brand-600">{orderStatusLabels[lastOrder.status]}</p>
            </div>
          </div>
        </div>
      ) : null}

      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-bold text-navy-900">Sana Özel Öneriler</h2>
          <Link href="/" className="flex items-center gap-1 text-xs font-semibold text-brand-600 hover:text-brand-700">
            Tümünü Gör <ArrowRight size={12} />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-4">
          {suggestions.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: typeof ClipboardList;
  label: string;
  value: number;
  href: string;
}) {
  return (
    <Link
      href={href}
      className="flex flex-col gap-2 rounded-2xl border border-navy-100/80 bg-white p-4 transition-shadow hover:shadow-card"
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
        <Icon size={17} />
      </span>
      <span className="text-2xl font-extrabold text-navy-900">{value}</span>
      <span className="text-xs font-medium text-navy-400">{label}</span>
    </Link>
  );
}

