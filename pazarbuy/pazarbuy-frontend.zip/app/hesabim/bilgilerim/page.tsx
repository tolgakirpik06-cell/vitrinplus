"use client";

import { useEffect, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { TextField } from "@/components/seller-application/fields";
import { formatPhoneInput, isValidEmail, isValidPhone } from "@/lib/auth";

export default function BilgilerimPage() {
  const { user, updateProfile } = useAuth();
  const [ad, setAd] = useState("");
  const [soyad, setSoyad] = useState("");
  const [email, setEmail] = useState("");
  const [telefon, setTelefon] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    setAd(user.ad);
    setSoyad(user.soyad);
    setEmail(user.email);
    setTelefon(user.telefon);
  }, [user]);

  if (!user) return null;

  const emailChanged = email.trim().toLowerCase() !== user.email.toLowerCase();
  const telefonChanged = telefon.trim() !== user.telefon;

  function handleSubmit() {
    const next: Record<string, string> = {};
    if (!ad.trim()) next.ad = "Ad girin.";
    if (!soyad.trim()) next.soyad = "Soyad girin.";
    if (!isValidEmail(email)) next.email = "Geçerli bir e-posta adresi girin.";
    if (!isValidPhone(telefon)) next.telefon = "Geçerli bir telefon numarası girin.";
    setErrors(next);
    setSaved(false);
    if (Object.keys(next).length > 0) return;

    const result = updateProfile({ ad: ad.trim(), soyad: soyad.trim(), email: email.trim(), telefon: telefon.trim() });
    if (!result.ok) {
      setFormError(result.error);
      return;
    }
    setFormError(null);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Hesap Bilgilerim</h1>
        <p className="mt-1 text-sm text-navy-400">Kişisel bilgilerini buradan güncelleyebilirsin.</p>
      </div>

      <div className="max-w-lg rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          <TextField label="Ad" id="bilgi-ad" required value={ad} error={errors.ad} onChange={(e) => setAd(e.target.value)} />
          <TextField
            label="Soyad"
            id="bilgi-soyad"
            required
            value={soyad}
            error={errors.soyad}
            onChange={(e) => setSoyad(e.target.value)}
          />
          <div className="sm:col-span-2">
            <TextField
              label="E-posta"
              id="bilgi-email"
              type="email"
              required
              value={email}
              error={errors.email}
              hint={emailChanged ? "E-postanı değiştirdiğinde ileride doğrulama gerekebilir." : undefined}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="sm:col-span-2">
            <TextField
              label="Telefon"
              id="bilgi-telefon"
              required
              inputMode="numeric"
              placeholder="05xx xxx xx xx"
              value={telefon}
              error={errors.telefon}
              hint={telefonChanged ? "Telefonunu değiştirdiğinde ileride doğrulama gerekebilir." : undefined}
              onChange={(e) => setTelefon(formatPhoneInput(e.target.value))}
            />
          </div>
        </div>

        {formError ? <p className="mt-3 text-xs font-medium text-rose-600">{formError}</p> : null}

        <div className="mt-4 flex items-center gap-3">
          <button
            type="button"
            onClick={handleSubmit}
            className="rounded-full bg-brand-500 px-5 py-2.5 text-xs font-semibold text-white hover:bg-brand-600"
          >
            Bilgileri Kaydet
          </button>
          {saved ? (
            <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
              <CheckCircle2 size={14} />
              Kaydedildi
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
