"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Copy, Ticket } from "lucide-react";
import { mockCoupons } from "@/data/account-mock";
import type { Coupon, CouponStatus } from "@/types/account";
import { cn } from "@/lib/utils";

const TABS: { id: CouponStatus; label: string }[] = [
  { id: "kullanilabilir", label: "Kullanılabilir" },
  { id: "kullanildi", label: "Kullanıldı" },
  { id: "suresi-dolmus", label: "Süresi Doldu" },
];

function formatValidUntil(iso: string): string {
  return new Date(iso).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" });
}

export default function KuponlarimPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<CouponStatus>("kullanilabilir");
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const filtered = useMemo(() => mockCoupons.filter((c) => c.status === activeTab), [activeTab]);

  function handleUse(coupon: Coupon) {
    // Gerçek bir kupon "uygulama" backend'i yok — kuponu sepete taşıyıp
    // kullanıcıyı sepet sayfasına yönlendiriyoruz, kod orada CartPageClient'ın
    // zaten çalışan kupon kutusuna elle girilebilir (PAZARBUY10 gerçekten çalışır).
    navigator.clipboard?.writeText(coupon.code).catch(() => {});
    setCopiedCode(coupon.code);
    window.setTimeout(() => setCopiedCode(null), 2000);
    router.push("/sepet");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Kuponlarım</h1>
        <p className="mt-1 text-sm text-navy-400">İndirim kuponlarını buradan yönetebilirsin.</p>
      </div>

      <div className="flex gap-1.5 overflow-x-auto">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-xs font-semibold transition-colors",
              activeTab === tab.id
                ? "border-brand-500 bg-brand-500 text-white"
                : "border-navy-100 bg-white text-navy-600 hover:border-navy-300"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-navy-100/80 bg-white px-6 py-14 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-navy-50 text-navy-400">
            <Ticket size={24} />
          </span>
          <p className="text-sm font-semibold text-navy-800">Bu kategoride kupon yok</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          {filtered.map((coupon) => (
            <div
              key={coupon.id}
              className={cn(
                "relative flex flex-col gap-3 overflow-hidden rounded-2xl border p-4",
                coupon.status === "kullanilabilir"
                  ? "border-brand-200 bg-brand-50/40"
                  : "border-navy-100/80 bg-navy-50/40 opacity-80"
              )}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span
                    className={cn(
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                      coupon.status === "kullanilabilir" ? "bg-brand-500 text-white" : "bg-navy-200 text-navy-500"
                    )}
                  >
                    <Ticket size={18} />
                  </span>
                  <div>
                    <p className="text-sm font-extrabold text-navy-900">{coupon.discountLabel}</p>
                    <p className="text-[11px] text-navy-400">{coupon.scope}</p>
                  </div>
                </div>
                <span className="rounded-md border border-dashed border-navy-300 px-2 py-1 font-mono text-[11px] font-bold text-navy-700">
                  {coupon.code}
                </span>
              </div>

              <div className="text-[11px] text-navy-400">
                {coupon.minCartLabel ? <p>{coupon.minCartLabel}</p> : null}
                <p>Son kullanım: {formatValidUntil(coupon.validUntil)}</p>
              </div>

              {coupon.status === "kullanilabilir" ? (
                <button
                  type="button"
                  onClick={() => handleUse(coupon)}
                  className="mt-1 flex items-center justify-center gap-1.5 rounded-full bg-brand-500 py-2 text-xs font-semibold text-white hover:bg-brand-600"
                >
                  {copiedCode === coupon.code ? (
                    <>
                      <CheckCircle2 size={13} />
                      Kod Kopyalandı
                    </>
                  ) : (
                    <>
                      <Copy size={13} />
                      Kullan
                    </>
                  )}
                </button>
              ) : (
                <span className="mt-1 text-center text-[11px] font-semibold text-navy-400">
                  {coupon.status === "kullanildi" ? "Bu kupon kullanıldı" : "Bu kuponun süresi doldu"}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
