"use client";

import { useEffect, useState } from "react";
import { Bell, CheckCircle2, Mail, MessageSquare, Smartphone } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { notificationPrefsStorageKey } from "@/lib/account";
import { defaultNotificationPreferences } from "@/types/account";
import type { NotificationChannel, NotificationPreferences } from "@/types/account";
import { cn } from "@/lib/utils";

const CHANNEL_META: { id: NotificationChannel; label: string; icon: typeof Mail }[] = [
  { id: "email", label: "E-posta", icon: Mail },
  { id: "sms", label: "SMS", icon: MessageSquare },
  { id: "push", label: "Push Bildirim", icon: Smartphone },
];

function readPrefs(userId: string): NotificationPreferences {
  try {
    const raw = window.localStorage.getItem(notificationPrefsStorageKey(userId));
    if (!raw) return defaultNotificationPreferences;
    const parsed = JSON.parse(raw) as NotificationPreferences;
    return {
      orders: { ...defaultNotificationPreferences.orders, ...parsed.orders },
      campaigns: { ...defaultNotificationPreferences.campaigns, ...parsed.campaigns },
    };
  } catch {
    return defaultNotificationPreferences;
  }
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (checked: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full transition-colors",
        checked ? "bg-brand-500" : "bg-navy-200"
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition-transform",
          checked ? "translate-x-[22px]" : "translate-x-0.5"
        )}
      />
    </button>
  );
}

export default function BildirimlerPage() {
  const { user } = useAuth();
  const [prefs, setPrefs] = useState<NotificationPreferences>(defaultNotificationPreferences);
  const [hydrated, setHydrated] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    if (!user) return;
    setPrefs(readPrefs(user.id));
    setHydrated(true);
  }, [user]);

  useEffect(() => {
    if (!user || !hydrated) return;
    try {
      window.localStorage.setItem(notificationPrefsStorageKey(user.id), JSON.stringify(prefs));
      setSavedFlash(true);
      const timeout = window.setTimeout(() => setSavedFlash(false), 1500);
      return () => window.clearTimeout(timeout);
    } catch {
      // best-effort
    }
  }, [prefs, user, hydrated]);

  if (!user) return null;

  function toggle(group: "orders" | "campaigns", channel: NotificationChannel, value: boolean) {
    setPrefs((prev) => ({ ...prev, [group]: { ...prev[group], [channel]: value } }));
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Bildirim Tercihleri</h1>
          <p className="mt-1 text-sm text-navy-400">Hangi bildirimleri nasıl almak istediğini seç.</p>
        </div>
        {savedFlash ? (
          <span className="flex shrink-0 items-center gap-1 text-xs font-semibold text-emerald-600">
            <CheckCircle2 size={14} />
            Kaydedildi
          </span>
        ) : null}
      </div>

      <div className="rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
            <Bell size={16} />
          </span>
          <div>
            <p className="text-sm font-bold text-navy-900">Sipariş Bildirimleri</p>
            <p className="text-[11px] text-navy-400">Sipariş durumu, kargo ve teslimat bilgilendirmeleri</p>
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-3">
          {CHANNEL_META.map((channel) => (
            <div key={channel.id} className="flex items-center justify-between gap-3">
              <span className="flex items-center gap-2 text-sm text-navy-700">
                <channel.icon size={15} className="text-navy-400" />
                {channel.label}
              </span>
              <Switch checked={prefs.orders[channel.id]} onChange={(v) => toggle("orders", channel.id, v)} />
            </div>
          ))}
        </div>
        <p className="mt-3 text-[11px] text-navy-400">
          Sipariş bildirimleri hesabının işleyişi için önemlidir; tamamen kapatman önerilmez.
        </p>
      </div>

      <div className="rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
            <Bell size={16} />
          </span>
          <div>
            <p className="text-sm font-bold text-navy-900">Kampanya ve Fırsatlar</p>
            <p className="text-[11px] text-navy-400">İndirim, kampanya ve öneri bildirimleri (pazarlama izni)</p>
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-3">
          {CHANNEL_META.map((channel) => (
            <div key={channel.id} className="flex items-center justify-between gap-3">
              <span className="flex items-center gap-2 text-sm text-navy-700">
                <channel.icon size={15} className="text-navy-400" />
                {channel.label}
              </span>
              <Switch checked={prefs.campaigns[channel.id]} onChange={(v) => toggle("campaigns", channel.id, v)} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
