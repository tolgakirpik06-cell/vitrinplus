"use client";

import { useFavorites } from "@/components/favorites/FavoritesProvider";
import { FavoritesPageContent } from "@/components/favorites/FavoritesPageContent";

export default function HesabimFavorilerimPage() {
  const { slugs } = useFavorites();

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Favorilerim</h1>
        <p className="mt-1 text-sm text-navy-400">{slugs.length} ürün favorilerinde</p>
      </div>
      <FavoritesPageContent />
    </div>
  );
}
