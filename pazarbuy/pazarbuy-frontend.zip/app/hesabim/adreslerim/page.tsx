"use client";

import { useEffect, useState } from "react";
import { Briefcase, Home as HomeIcon, MapPin, MoreHorizontal, Pencil, Plus, Star, Trash2, X } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { TextField, SelectField } from "@/components/seller-application/fields";
import { addressesStorageKey, generateId } from "@/lib/account";
import { formatPhoneInput, isValidPhone } from "@/lib/auth";
import type { Address, AddressType } from "@/types/account";
import { cn } from "@/lib/utils";

const IL_LIST = [
  "İstanbul",
  "Ankara",
  "İzmir",
  "Bursa",
  "Antalya",
  "Adana",
  "Konya",
  "Gaziantep",
  "Kayseri",
  "Trabzon",
];

const TYPE_LABEL: Record<AddressType, string> = { ev: "Ev", is: "İş", diger: "Diğer" };
const TYPE_ICON: Record<AddressType, typeof HomeIcon> = { ev: HomeIcon, is: Briefcase, diger: MoreHorizontal };

type FormState = {
  title: string;
  ad: string;
  soyad: string;
  telefon: string;
  il: string;
  ilce: string;
  mahalle: string;
  acikAdres: string;
  postaKodu: string;
  type: AddressType;
};

const emptyForm: FormState = {
  title: "",
  ad: "",
  soyad: "",
  telefon: "",
  il: "",
  ilce: "",
  mahalle: "",
  acikAdres: "",
  postaKodu: "",
  type: "ev",
};

export default function AdreslerimPage() {
  const { user } = useAuth();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!user) return;
    try {
      const raw = window.localStorage.getItem(addressesStorageKey(user.id));
      const parsed = raw ? (JSON.parse(raw) as Address[]) : [];
      setAddresses(Array.isArray(parsed) ? parsed : []);
    } catch {
      setAddresses([]);
    } finally {
      setHydrated(true);
    }
  }, [user]);

  useEffect(() => {
    if (!user || !hydrated) return;
    try {
      window.localStorage.setItem(addressesStorageKey(user.id), JSON.stringify(addresses));
    } catch {
      // best-effort
    }
  }, [addresses, user, hydrated]);

  if (!user) return null;

  function resetForm() {
    setForm(emptyForm);
    setErrors({});
    setEditingId(null);
    setShowForm(false);
  }

  function startCreate() {
    setForm(emptyForm);
    setErrors({});
    setEditingId(null);
    setShowForm(true);
  }

  function startEdit(address: Address) {
    setForm({
      title: address.title,
      ad: address.ad,
      soyad: address.soyad,
      telefon: address.telefon,
      il: address.il,
      ilce: address.ilce,
      mahalle: address.mahalle,
      acikAdres: address.acikAdres,
      postaKodu: address.postaKodu ?? "",
      type: address.type,
    });
    setErrors({});
    setEditingId(address.id);
    setShowForm(true);
  }

  function validate(): Record<string, string> {
    const next: Record<string, string> = {};
    if (!form.title.trim()) next.title = "Adres başlığı girin.";
    if (!form.ad.trim()) next.ad = "Ad girin.";
    if (!form.soyad.trim()) next.soyad = "Soyad girin.";
    if (!isValidPhone(form.telefon)) next.telefon = "Geçerli bir telefon numarası girin.";
    if (!form.il.trim()) next.il = "İl seçin.";
    if (!form.ilce.trim()) next.ilce = "İlçe girin.";
    if (!form.mahalle.trim()) next.mahalle = "Mahalle girin.";
    if (!form.acikAdres.trim()) next.acikAdres = "Açık adres girin.";
    return next;
  }

  function handleSubmit() {
    const validation = validate();
    setErrors(validation);
    if (Object.keys(validation).length > 0) return;

    if (editingId) {
      setAddresses((prev) =>
        prev.map((a) => (a.id === editingId ? { ...a, ...form, telefon: form.telefon.trim() } : a))
      );
    } else {
      const newAddress: Address = {
        id: generateId("adr"),
        ...form,
        telefon: form.telefon.trim(),
        isDefault: addresses.length === 0,
      };
      setAddresses((prev) => [...prev, newAddress]);
    }
    resetForm();
  }

  function handleDelete(id: string) {
    setAddresses((prev) => {
      const next = prev.filter((a) => a.id !== id);
      const removedWasDefault = prev.find((a) => a.id === id)?.isDefault;
      if (removedWasDefault && next.length > 0) next[0] = { ...next[0], isDefault: true };
      return next;
    });
  }

  function handleSetDefault(id: string) {
    setAddresses((prev) => prev.map((a) => ({ ...a, isDefault: a.id === id })));
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-navy-900 sm:text-2xl">Adreslerim</h1>
          <p className="mt-1 text-sm text-navy-400">{addresses.length} kayıtlı adres</p>
        </div>
        {!showForm ? (
          <button
            type="button"
            onClick={startCreate}
            className="flex items-center gap-1.5 rounded-full bg-brand-500 px-4 py-2.5 text-xs font-semibold text-white hover:bg-brand-600"
          >
            <Plus size={14} />
            Yeni Adres
          </button>
        ) : null}
      </div>

      {showForm ? (
        <div className="rounded-2xl border border-navy-100/80 bg-white p-4 sm:p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-navy-900">{editingId ? "Adresi Düzenle" : "Yeni Adres Ekle"}</h2>
            <button
              type="button"
              onClick={resetForm}
              className="flex h-8 w-8 items-center justify-center rounded-full text-navy-400 hover:bg-navy-50"
              aria-label="Kapat"
            >
              <X size={16} />
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
            <TextField
              label="Adres Başlığı"
              id="adr-title"
              required
              placeholder="Ev, İş vb."
              value={form.title}
              error={errors.title}
              onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            />
            <SelectField
              label="Adres Tipi"
              id="adr-type"
              options={["Ev", "İş", "Diğer"]}
              value={TYPE_LABEL[form.type]}
              onChange={(e) => {
                const label = e.target.value;
                const type = (Object.keys(TYPE_LABEL) as AddressType[]).find((k) => TYPE_LABEL[k] === label) ?? "ev";
                setForm((f) => ({ ...f, type }));
              }}
            />
            <TextField
              label="Ad"
              id="adr-ad"
              required
              value={form.ad}
              error={errors.ad}
              onChange={(e) => setForm((f) => ({ ...f, ad: e.target.value }))}
            />
            <TextField
              label="Soyad"
              id="adr-soyad"
              required
              value={form.soyad}
              error={errors.soyad}
              onChange={(e) => setForm((f) => ({ ...f, soyad: e.target.value }))}
            />
            <TextField
              label="Telefon"
              id="adr-telefon"
              required
              inputMode="numeric"
              placeholder="05xx xxx xx xx"
              value={form.telefon}
              error={errors.telefon}
              onChange={(e) => setForm((f) => ({ ...f, telefon: formatPhoneInput(e.target.value) }))}
            />
            <SelectField
              label="İl"
              id="adr-il"
              required
              options={IL_LIST}
              value={form.il}
              error={errors.il}
              onChange={(e) => setForm((f) => ({ ...f, il: e.target.value }))}
            />
            <TextField
              label="İlçe"
              id="adr-ilce"
              required
              value={form.ilce}
              error={errors.ilce}
              onChange={(e) => setForm((f) => ({ ...f, ilce: e.target.value }))}
            />
            <TextField
              label="Mahalle"
              id="adr-mahalle"
              required
              value={form.mahalle}
              error={errors.mahalle}
              onChange={(e) => setForm((f) => ({ ...f, mahalle: e.target.value }))}
            />
            <TextField
              label="Posta Kodu"
              id="adr-posta"
              hint="Opsiyonel"
              inputMode="numeric"
              value={form.postaKodu}
              onChange={(e) => setForm((f) => ({ ...f, postaKodu: e.target.value.replace(/\D/g, "").slice(0, 5) }))}
            />
            <div className="sm:col-span-2">
              <TextField
                label="Açık Adres"
                id="adr-acik"
                required
                placeholder="Sokak, bina no, daire no..."
                value={form.acikAdres}
                error={errors.acikAdres}
                onChange={(e) => setForm((f) => ({ ...f, acikAdres: e.target.value }))}
              />
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleSubmit}
              className="rounded-full bg-brand-500 px-5 py-2.5 text-xs font-semibold text-white hover:bg-brand-600"
            >
              {editingId ? "Kaydet" : "Adresi Ekle"}
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="rounded-full border border-navy-100 px-5 py-2.5 text-xs font-semibold text-navy-600 hover:border-navy-300"
            >
              Vazgeç
            </button>
          </div>
        </div>
      ) : null}

      {addresses.length === 0 && !showForm ? (
        <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-navy-100/80 bg-white px-6 py-14 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-brand-500">
            <MapPin size={24} />
          </span>
          <p className="text-sm font-semibold text-navy-800">Henüz kayıtlı adresin yok</p>
          <p className="max-w-xs text-xs text-navy-400">
            Sipariş verirken adres bilgilerini tekrar tekrar yazmamak için buradan adres ekleyebilirsin.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          {addresses.map((address) => {
            const TypeIcon = TYPE_ICON[address.type];
            return (
              <div key={address.id} className="flex flex-col gap-3 rounded-2xl border border-navy-100/80 bg-white p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-navy-50 text-navy-500">
                      <TypeIcon size={16} />
                    </span>
                    <div>
                      <p className="text-sm font-bold text-navy-900">{address.title}</p>
                      <p className="text-[11px] text-navy-400">{TYPE_LABEL[address.type]}</p>
                    </div>
                  </div>
                  {address.isDefault ? (
                    <span className="flex shrink-0 items-center gap-1 rounded-full bg-brand-50 px-2.5 py-1 text-[10px] font-bold text-brand-700">
                      <Star size={10} className="fill-brand-600 text-brand-600" />
                      Varsayılan
                    </span>
                  ) : null}
                </div>

                <div className="text-xs leading-relaxed text-navy-500">
                  <p className="font-semibold text-navy-700">
                    {address.ad} {address.soyad} · {address.telefon}
                  </p>
                  <p className="mt-0.5">
                    {address.mahalle}, {address.acikAdres}
                  </p>
                  <p>
                    {address.ilce}/{address.il}
                    {address.postaKodu ? ` — ${address.postaKodu}` : ""}
                  </p>
                </div>

                <div className="mt-1 flex flex-wrap items-center gap-2 border-t border-navy-50 pt-2.5">
                  {!address.isDefault ? (
                    <button
                      type="button"
                      onClick={() => handleSetDefault(address.id)}
                      className="rounded-full border border-navy-100 px-3 py-1.5 text-[11px] font-semibold text-navy-600 hover:border-brand-300 hover:text-brand-700"
                    >
                      Varsayılan Yap
                    </button>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => startEdit(address)}
                    className={cn(
                      "flex items-center gap-1 rounded-full border border-navy-100 px-3 py-1.5 text-[11px] font-semibold text-navy-600 hover:border-navy-300"
                    )}
                  >
                    <Pencil size={11} />
                    Düzenle
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(address.id)}
                    className="flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-semibold text-navy-400 hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 size={11} />
                    Sil
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
