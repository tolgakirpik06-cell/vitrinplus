import type { Metadata } from "next";
import { Heart } from "lucide-react";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Breadcrumb } from "@/components/ui/Breadcrumb";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { FavoritesPageContent } from "@/components/favorites/FavoritesPageContent";

export const metadata: Metadata = { title: "Favorilerim | PazarBuy" };

export default function FavorilerPage() {
  return (
    <>
      <Header />

      <main className="section-container flex flex-col gap-6 py-6">
        <Breadcrumb items={[{ label: "Ana Sayfa", href: "/" }, { label: "Favorilerim" }]} />

        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-500">
            <Heart size={20} className="fill-rose-500" />
          </span>
          <div>
            <h1 className="text-2xl font-extrabold text-navy-900 sm:text-3xl">Favorilerim</h1>
            <p className="mt-1 text-sm text-navy-400">Beğendiğin ürünler burada listelenir.</p>
          </div>
        </div>

        <RequireAuth>
          <FavoritesPageContent />
        </RequireAuth>
      </main>

      <Footer />
    </>
  );
}
