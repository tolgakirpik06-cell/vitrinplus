"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  ClipboardList,
  Heart,
  MapPin,
  Ticket,
  Star,
  Bell,
  UserCog,
  ShieldCheck,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/hesabim", label: "Hesap Özeti", icon: LayoutDashboard },
  { href: "/hesabim/siparislerim", label: "Siparişlerim", icon: ClipboardList },
  { href: "/hesabim/favorilerim", label: "Favorilerim", icon: Heart },
  { href: "/hesabim/adreslerim", label: "Adreslerim", icon: MapPin },
  { href: "/hesabim/kuponlarim", label: "Kuponlarım", icon: Ticket },
  { href: "/hesabim/degerlendirmelerim", label: "Değerlendirmelerim", icon: Star },
  { href: "/hesabim/bildirimler", label: "Bildirim Tercihleri", icon: Bell },
  { href: "/hesabim/bilgilerim", label: "Hesap Bilgilerim", icon: UserCog },
  { href: "/hesabim/guvenlik", label: "Güvenlik", icon: ShieldCheck },
];

export function AccountNav() {
  const pathname = usePathname();
  const { logout } = useAuth();
  const router = useRouter();

  return (
    <>
      {/* Masaüstü: dikey sidebar */}
      <nav className="hidden w-60 shrink-0 flex-col gap-1 lg:flex">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-brand-50 text-brand-700"
                  : "text-navy-600 hover:bg-navy-50 hover:text-navy-800"
              )}
            >
              <item.icon size={17} className={isActive ? "text-brand-600" : "text-navy-400"} />
              {item.label}
            </Link>
          );
        })}
        <div className="my-1.5 h-px bg-navy-100" />
        <button
          type="button"
          onClick={() => {
            logout();
            router.push("/");
          }}
          className="flex items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-left text-sm font-semibold text-rose-600 transition-colors hover:bg-rose-50"
        >
          <LogOut size={17} />
          Çıkış Yap
        </button>
      </nav>

      {/* Mobil: taşmayan yatay kaydırmalı sekme şeridi */}
      <nav className="-mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1 lg:hidden">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors",
                isActive
                  ? "border-brand-500 bg-brand-500 text-white"
                  : "border-navy-100 bg-white text-navy-600"
              )}
            >
              <item.icon size={14} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </>
  );
}
