"use client";

import type { ReactNode } from "react";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { AccountNav } from "@/components/account/AccountNav";

/**
 * /hesabim/* rotalarının ortak kabuğu: giriş yapılmamışsa RequireAuth
 * kullanıcıyı /giris'e yönlendirir; giriş yapılmışsa masaüstünde sol
 * sidebar + sağda içerik, mobilde üstte yatay sekme şeridi + altta
 * içerik şeklinde responsive bir düzen kurar.
 */
export function AccountShell({ children }: { children: ReactNode }) {
  return (
    <RequireAuth>
      <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:gap-8">
        <AccountNav />
        <div className="min-w-0 flex-1">{children}</div>
      </div>
    </RequireAuth>
  );
}
