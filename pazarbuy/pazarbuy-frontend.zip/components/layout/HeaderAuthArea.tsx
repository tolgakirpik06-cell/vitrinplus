"use client";

import { useState } from "react";
import Link from "next/link";
import { ChevronDown, ClipboardList, Heart, LogIn, LogOut, User, UserPlus } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

/**
 * Header'ın sağındaki giriş/üye-ol ya da kullanıcı dropdown'ı — auth
 * state client'ta bilindiği için ayrı bir Client Component olarak
 * çıkarıldı (Header.tsx server component olarak kalabiliyor).
 */
export function HeaderAuthArea() {
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const [open, setOpen] = useState(false);

  if (isLoading) {
    return <div className="h-9 w-[9.5rem]" aria-hidden />;
  }

  if (!isAuthenticated || !user) {
    return (
      <>
        <Button href="/giris" variant="outline" size="sm" className="whitespace-nowrap">
          <LogIn size={15} />
          Giriş Yap
        </Button>
        <Button href="/kayit" variant="primary" size="sm" className="whitespace-nowrap">
          <UserPlus size={15} />
          Üye Ol
        </Button>
      </>
    );
  }

  const initials = `${user.ad.charAt(0)}${user.soyad.charAt(0)}`.toUpperCase();

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-full py-1 pl-1 pr-2.5 text-navy-700 transition-colors hover:bg-navy-50"
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-50 text-xs font-bold text-brand-600">
          {initials}
        </span>
        <span className="max-w-[6.5rem] truncate text-sm font-semibold">{user.ad}</span>
        <ChevronDown size={14} className={cn("shrink-0 text-navy-400 transition-transform", open && "rotate-180")} />
      </button>

      {open ? (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} aria-hidden />
          <div className="absolute right-0 top-full z-50 mt-2 w-56 rounded-2xl border border-navy-100/80 bg-white p-2 shadow-card-hover">
            <Link
              href="/hesabim/siparislerim"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium text-navy-700 hover:bg-navy-50"
            >
              <ClipboardList size={16} className="text-navy-400" />
              Siparişlerim
            </Link>
            <Link
              href="/hesabim/favorilerim"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium text-navy-700 hover:bg-navy-50"
            >
              <Heart size={16} className="text-navy-400" />
              Favorilerim
            </Link>
            <Link
              href="/hesabim"
              onClick={() => setOpen(false)}
              className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium text-navy-700 hover:bg-navy-50"
            >
              <User size={16} className="text-navy-400" />
              Hesabım
            </Link>
            <div className="my-1.5 h-px bg-navy-50" />
            <button
              type="button"
              onClick={() => {
                logout();
                setOpen(false);
              }}
              className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-semibold text-rose-600 hover:bg-rose-50"
            >
              <LogOut size={16} />
              Çıkış Yap
            </button>
          </div>
        </>
      ) : null}
    </div>
  );
}
