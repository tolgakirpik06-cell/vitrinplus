"use client";

import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { FieldWrapper } from "@/components/seller-application/fields";
import { getPasswordStrength } from "@/lib/auth";
import { cn } from "@/lib/utils";

const strengthLabel: Record<string, string> = {
  zayif: "Zayıf",
  orta: "Orta",
  guclu: "Güçlü",
};

export function PasswordField({
  id,
  label,
  value,
  onChange,
  error,
  required,
  hint,
  showStrength,
  autoComplete,
  placeholder,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  required?: boolean;
  hint?: string;
  showStrength?: boolean;
  autoComplete?: string;
  placeholder?: string;
}) {
  const [visible, setVisible] = useState(false);
  const strength = showStrength ? getPasswordStrength(value) : null;

  return (
    <FieldWrapper label={label} htmlFor={id} required={required} error={error} hint={hint}>
      <div className="relative">
        <input
          id={id}
          type={visible ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          placeholder={placeholder}
          className={cn(
            "h-11 w-full rounded-xl border bg-white pl-3.5 pr-11 text-sm text-navy-900 outline-none transition-colors placeholder:text-navy-300 focus:border-brand-400 focus:ring-4 focus:ring-brand-500/10",
            error ? "border-rose-300" : "border-navy-100"
          )}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-400 transition-colors hover:text-navy-600"
          aria-label={visible ? "Şifreyi gizle" : "Şifreyi göster"}
          tabIndex={-1}
        >
          {visible ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>

      {showStrength && value ? (
        <div className="mt-1.5 flex items-center gap-2">
          <div className="flex h-1 flex-1 gap-1">
            <span
              className={cn(
                "h-full flex-1 rounded-full",
                strength === "zayif" || strength === "orta" || strength === "guclu"
                  ? "bg-rose-400"
                  : "bg-navy-100"
              )}
            />
            <span
              className={cn(
                "h-full flex-1 rounded-full",
                strength === "orta" ? "bg-amber-400" : strength === "guclu" ? "bg-emerald-500" : "bg-navy-100"
              )}
            />
            <span
              className={cn("h-full flex-1 rounded-full", strength === "guclu" ? "bg-emerald-500" : "bg-navy-100")}
            />
          </div>
          <span className="shrink-0 text-[11px] font-medium text-navy-400">
            {strength ? strengthLabel[strength] : ""}
          </span>
        </div>
      ) : null}
    </FieldWrapper>
  );
}
