"use client";

import { useState } from "react";
import { Info } from "lucide-react";

/**
 * Google/Apple ile giriş butonları — GERÇEK OAuth entegrasyonu YOK.
 * Butona basılınca çalışıyormuş gibi davranmak yerine net bir
 * "henüz yapılandırılmadı" mesajı gösteriyoruz. Kod, ileride gerçek
 * OAuth sağlayıcıları bağlanabilecek şekilde (her sağlayıcı kendi
 * onClick handler'ına sahip) temiz tutuldu.
 */
export function SocialLoginButtons() {
  const [notice, setNotice] = useState<string | null>(null);

  function handleProviderClick(provider: string) {
    setNotice(`${provider} ile giriş henüz yapılandırılmadı.`);
    window.setTimeout(() => setNotice(null), 3500);
  }

  return (
    <div className="flex flex-col gap-2.5">
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => handleProviderClick("Google")}
          className="flex items-center justify-center gap-2 rounded-xl border border-navy-100 bg-white px-4 py-2.5 text-sm font-semibold text-navy-700 transition-colors hover:border-navy-300 hover:bg-navy-50"
        >
          <GoogleIcon />
          Google
        </button>
        <button
          type="button"
          onClick={() => handleProviderClick("Apple")}
          className="flex items-center justify-center gap-2 rounded-xl border border-navy-100 bg-white px-4 py-2.5 text-sm font-semibold text-navy-700 transition-colors hover:border-navy-300 hover:bg-navy-50"
        >
          <AppleIcon />
          Apple
        </button>
      </div>

      {notice ? (
        <p className="flex items-center gap-1.5 rounded-lg bg-navy-50 px-3 py-2 text-[11px] font-medium text-navy-500">
          <Info size={13} className="shrink-0 text-navy-400" />
          {notice}
        </p>
      ) : null}
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden>
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.82-.07-1.42-.22-2.05H12v3.72h6.51c-.13 1.05-.84 2.63-2.42 3.7l-.02.15 3.52 2.7.24.02c2.24-2.06 3.53-5.1 3.53-8.24"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.05 7.93-2.87l-3.78-2.92c-1.01.7-2.38 1.19-4.15 1.19-3.17 0-5.86-2.09-6.82-4.97l-.14.01-3.66 2.82-.05.13C3.36 21.34 7.36 24 12 24"
      />
      <path
        fill="#FBBC05"
        d="M5.18 14.43a7.4 7.4 0 0 1-.4-2.4c0-.84.15-1.65.39-2.4l-.01-.16-3.7-2.87-.12.06A11.94 11.94 0 0 0 0 12.03c0 1.93.47 3.76 1.3 5.37z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c2.26 0 3.78.97 4.65 1.79l3.39-3.3C17.94 1.19 15.24 0 12 0 7.36 0 3.36 2.66 1.34 6.62l3.83 2.98c.97-2.88 3.66-4.85 6.83-4.85"
      />
    </svg>
  );
}

function AppleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden>
      <path
        fill="#000000"
        d="M16.36 1.43c0 1.14-.42 2.2-1.24 3.06-.87.9-2.06 1.59-3.16 1.5-.14-1.1.4-2.24 1.2-3.1.83-.9 2.24-1.56 3.2-1.46M20.5 17.2c-.55 1.27-.82 1.83-1.53 2.95-.99 1.56-2.39 3.5-4.12 3.52-1.53.02-1.92-1-4-.98-2.07.01-2.5 1-4.03.98-1.73-.02-3.06-1.77-4.05-3.33C.34 17.05-.4 12.5 1.14 9.4c1.09-2.2 3.04-3.6 5.14-3.63 1.63-.03 3.17 1.1 4.16 1.1.98 0 2.85-1.36 4.8-1.16.82.03 3.11.33 4.58 2.5-.12.07-2.74 1.6-2.7 4.77.03 3.8 3.33 5.06 3.38 5.08z"
      />
    </svg>
  );
}
