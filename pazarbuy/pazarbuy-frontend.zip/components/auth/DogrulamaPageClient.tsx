"use client";

import { useEffect, useRef, useState, type ClipboardEvent, type KeyboardEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CheckCircle2, Info, MailCheck, RotateCcw } from "lucide-react";
import { AuthSplitLayout } from "@/components/auth/AuthSplitLayout";
import { useAuth } from "@/components/auth/AuthProvider";
import { cn } from "@/lib/utils";

const CODE_LENGTH = 6;
const RESEND_SECONDS = 60;
/** Gerçek bir SMS/e-posta servisi olmadığı için demo modunda geçerli sayılan sabit kod. */
const DEMO_CODE = "123456";

export function DogrulamaPageClient() {
  const { user } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/";

  const [digits, setDigits] = useState<string[]>(Array(CODE_LENGTH).fill(""));
  const [status, setStatus] = useState<"idle" | "error" | "success">("idle");
  const [secondsLeft, setSecondsLeft] = useState(RESEND_SECONDS);
  const inputsRef = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const timer = window.setTimeout(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [secondsLeft]);

  function handleChange(index: number, value: string) {
    const digit = value.replace(/\D/g, "").slice(-1);
    setStatus("idle");
    setDigits((prev) => {
      const next = [...prev];
      next[index] = digit;
      return next;
    });
    if (digit && index < CODE_LENGTH - 1) {
      inputsRef.current[index + 1]?.focus();
    }
  }

  function handleKeyDown(index: number, event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Backspace" && !digits[index] && index > 0) {
      inputsRef.current[index - 1]?.focus();
    }
  }

  function handlePaste(event: ClipboardEvent<HTMLInputElement>) {
    const pasted = event.clipboardData.getData("text").replace(/\D/g, "").slice(0, CODE_LENGTH);
    if (!pasted) return;
    event.preventDefault();
    setDigits((prev) => {
      const next = [...prev];
      pasted.split("").forEach((d, i) => {
        next[i] = d;
      });
      return next;
    });
    inputsRef.current[Math.min(pasted.length, CODE_LENGTH - 1)]?.focus();
  }

  function handleResend() {
    if (secondsLeft > 0) return;
    setSecondsLeft(RESEND_SECONDS);
    setDigits(Array(CODE_LENGTH).fill(""));
    setStatus("idle");
    inputsRef.current[0]?.focus();
  }

  function handleVerify() {
    const code = digits.join("");
    if (code.length < CODE_LENGTH) return;
    setStatus(code === DEMO_CODE ? "success" : "error");
  }

  if (status === "success") {
    return (
      <AuthSplitLayout eyebrow="Doğrulama" title="Doğrulandı!">
        <div className="flex flex-col items-center gap-4 py-4 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-500">
            <CheckCircle2 size={28} />
          </span>
          <p className="text-sm text-navy-500">Hesabın başarıyla doğrulandı. Artık PazarBuy&apos;da alışverişe başlayabilirsin.</p>
          <button
            type="button"
            onClick={() => router.push(redirectTo)}
            className="mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600"
          >
            Devam Et
          </button>
        </div>
      </AuthSplitLayout>
    );
  }

  return (
    <AuthSplitLayout
      eyebrow="Doğrulama"
      title="Hesabını Doğrula"
      subtitle={
        user
          ? `${user.email} adresine veya ${user.telefon} numarasına gönderilen kodu girin.`
          : "E-posta adresinize veya telefonunuza gönderilen kodu girin."
      }
    >
      <div className="flex flex-col gap-5">
        <p className="flex items-start gap-2.5 rounded-xl border border-navy-100 bg-navy-50/50 px-4 py-3 text-xs leading-relaxed text-navy-500">
          <Info size={15} className="mt-0.5 shrink-0 text-navy-400" />
          Bu demo sürümünde gerçek bir SMS/e-posta servisi bağlı değil, bu yüzden gerçek bir kod
          gönderilmiyor. Devam etmek için <span className="font-semibold text-navy-700">{DEMO_CODE}</span>{" "}
          kodunu girebilirsin.
        </p>

        <div className="flex items-center justify-center gap-2 sm:gap-2.5">
          {digits.map((digit, index) => (
            <input
              key={index}
              ref={(el) => {
                inputsRef.current[index] = el;
              }}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onPaste={handlePaste}
              className={cn(
                "h-12 w-10 rounded-xl border text-center text-lg font-bold text-navy-900 outline-none transition-colors focus:border-brand-400 focus:ring-4 focus:ring-brand-500/10 sm:h-14 sm:w-12",
                status === "error" ? "border-rose-300" : "border-navy-100"
              )}
            />
          ))}
        </div>

        {status === "error" ? (
          <p className="text-center text-xs font-medium text-rose-600">
            Girdiğiniz kod hatalı, tekrar deneyin.
          </p>
        ) : null}

        <button
          type="button"
          onClick={handleVerify}
          disabled={digits.some((d) => !d)}
          className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600 disabled:opacity-40"
        >
          <MailCheck size={16} />
          Kodu Doğrula
        </button>

        <button
          type="button"
          onClick={handleResend}
          disabled={secondsLeft > 0}
          className="flex items-center justify-center gap-1.5 text-xs font-semibold text-brand-600 transition-colors hover:text-brand-700 disabled:cursor-not-allowed disabled:text-navy-300"
        >
          <RotateCcw size={13} />
          {secondsLeft > 0 ? `Kodu tekrar gönder (${secondsLeft}s)` : "Kodu tekrar gönder"}
        </button>
      </div>
    </AuthSplitLayout>
  );
}
