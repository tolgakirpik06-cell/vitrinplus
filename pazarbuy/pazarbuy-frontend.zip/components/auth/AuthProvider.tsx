"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  AUTH_DIRECTORY_KEY,
  AUTH_SESSION_KEY,
  generateUserId,
  hashPassword,
  isValidEmail,
  isValidPassword,
  isValidPhone,
  normalizePhone,
} from "@/lib/auth";
import type {
  AuthResult,
  AuthUser,
  LoginInput,
  PasswordChangeInput,
  PasswordResetInput,
  ProfileUpdateInput,
  RegisterInput,
} from "@/types/auth";

/**
 * DEMO/MOCK kimlik doğrulama sistemi. Gerçek bir backend yok — kullanıcı
 * "dizini" (email/telefon + şifre HASH'i) ve aktif oturum localStorage/
 * sessionStorage'da tutulur. Şifrenin kendisi ASLA saklanmaz, sadece
 * SHA-256 hash'i (bkz. lib/auth.ts'teki uyarı). Gerçek backend
 * bağlandığında sadece bu dosyanın içi (register/login/logout/
 * updateProfile gövdeleri) değişmeli; login/register/logout çağıran
 * component'lerin hiçbiri değişmemeli.
 */

type DirectoryEntry = AuthUser & { passwordHash: string };

function readDirectory(): DirectoryEntry[] {
  try {
    const raw = window.localStorage.getItem(AUTH_DIRECTORY_KEY);
    const parsed = raw ? (JSON.parse(raw) as DirectoryEntry[]) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeDirectory(directory: DirectoryEntry[]) {
  try {
    window.localStorage.setItem(AUTH_DIRECTORY_KEY, JSON.stringify(directory));
  } catch {
    // best-effort — demo dizini yazılamazsa oturum yine de bellekte çalışmaya devam eder.
  }
}

function readSessionUserId(): string | null {
  try {
    return (
      window.localStorage.getItem(AUTH_SESSION_KEY) ??
      window.sessionStorage.getItem(AUTH_SESSION_KEY)
    );
  } catch {
    return null;
  }
}

function writeSession(userId: string, rememberMe: boolean) {
  try {
    if (rememberMe) {
      window.localStorage.setItem(AUTH_SESSION_KEY, userId);
      window.sessionStorage.removeItem(AUTH_SESSION_KEY);
    } else {
      window.sessionStorage.setItem(AUTH_SESSION_KEY, userId);
      window.localStorage.removeItem(AUTH_SESSION_KEY);
    }
  } catch {
    // best-effort
  }
}

function clearSession() {
  try {
    window.localStorage.removeItem(AUTH_SESSION_KEY);
    window.sessionStorage.removeItem(AUTH_SESSION_KEY);
  } catch {
    // best-effort
  }
}

function toPublicUser(entry: DirectoryEntry): AuthUser {
  const { passwordHash: _passwordHash, ...user } = entry;
  void _passwordHash;
  return user;
}

type AuthContextValue = {
  user: AuthUser | null;
  isAuthenticated: boolean;
  /** true = localStorage/sessionStorage henüz okunmadı (hydration aşaması). */
  isLoading: boolean;
  register: (input: RegisterInput) => Promise<AuthResult>;
  login: (input: LoginInput) => Promise<AuthResult>;
  logout: () => void;
  updateProfile: (patch: ProfileUpdateInput) => AuthResult;
  changePassword: (input: PasswordChangeInput) => Promise<AuthResult>;
  /** "Şifremi unuttum" akışının 1. adımı — hesap var mı diye bakar (kod göndermeden önce). */
  identifierExists: (identifier: string) => boolean;
  /** "Şifremi unuttum" akışının son adımı — mevcut şifre bilinmeden yenisi belirlenir. */
  resetPassword: (input: PasswordResetInput) => Promise<AuthResult>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const userId = readSessionUserId();
      if (userId) {
        const entry = readDirectory().find((u) => u.id === userId);
        if (entry) setUser(toPublicUser(entry));
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  const register = useCallback(async (input: RegisterInput): Promise<AuthResult> => {
    const ad = input.ad.trim();
    const soyad = input.soyad.trim();
    const email = input.email.trim().toLowerCase();

    if (!ad || !soyad) return { ok: false, error: "Ad ve soyad zorunludur." };
    if (!isValidEmail(email)) return { ok: false, error: "Geçerli bir e-posta adresi girin." };
    if (!isValidPhone(input.telefon)) return { ok: false, error: "Geçerli bir telefon numarası girin." };
    if (!isValidPassword(input.sifre)) return { ok: false, error: "Şifre en az 8 karakter olmalı." };
    if (input.sifre !== input.sifreTekrar) return { ok: false, error: "Şifreler eşleşmiyor." };
    if (!input.uyelikSozlesmesiKabul) return { ok: false, error: "Üyelik sözleşmesini onaylamalısınız." };
    if (!input.kvkkKabul) return { ok: false, error: "KVKK metnini onaylamalısınız." };

    const directory = readDirectory();
    const normalizedPhone = normalizePhone(input.telefon);
    const emailTaken = directory.some((u) => u.email.toLowerCase() === email);
    const phoneTaken = directory.some((u) => normalizePhone(u.telefon) === normalizedPhone);
    if (emailTaken) return { ok: false, error: "Bu e-posta adresiyle zaten bir hesap var." };
    if (phoneTaken) return { ok: false, error: "Bu telefon numarasıyla zaten bir hesap var." };

    const passwordHash = await hashPassword(input.sifre);
    const entry: DirectoryEntry = {
      id: generateUserId(),
      ad,
      soyad,
      email,
      telefon: input.telefon.trim(),
      createdAt: new Date().toISOString(),
      passwordHash,
    };

    writeDirectory([...directory, entry]);
    writeSession(entry.id, true);
    setUser(toPublicUser(entry));
    return { ok: true };
  }, []);

  const login = useCallback(async (input: LoginInput): Promise<AuthResult> => {
    const identifier = input.identifier.trim().toLowerCase();
    if (!identifier) return { ok: false, error: "E-posta veya telefon girin." };
    if (!input.sifre) return { ok: false, error: "Şifre girin." };

    const directory = readDirectory();
    const normalizedIdentifier = normalizePhone(input.identifier);
    const entry = directory.find(
      (u) => u.email.toLowerCase() === identifier || normalizePhone(u.telefon) === normalizedIdentifier
    );

    // Kayıtlı olmayan bir kullanıcı ile aynı jenerik hata mesajı — hangi
    // alanın yanlış olduğunu belli etmemek gerçek sistemlerde de iyi
    // pratiktir.
    const genericError = { ok: false as const, error: "E-posta/telefon veya şifre hatalı." };
    if (!entry) return genericError;

    const passwordHash = await hashPassword(input.sifre);
    if (passwordHash !== entry.passwordHash) return genericError;

    writeSession(entry.id, input.beniHatirla);
    setUser(toPublicUser(entry));
    return { ok: true };
  }, []);

  const logout = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const updateProfile = useCallback(
    (patch: ProfileUpdateInput): AuthResult => {
      if (!user) return { ok: false, error: "Bu işlem için giriş yapmalısınız." };
      if (patch.email !== undefined && !isValidEmail(patch.email)) {
        return { ok: false, error: "Geçerli bir e-posta adresi girin." };
      }
      if (patch.telefon !== undefined && !isValidPhone(patch.telefon)) {
        return { ok: false, error: "Geçerli bir telefon numarası girin." };
      }

      const directory = readDirectory();
      const index = directory.findIndex((u) => u.id === user.id);
      if (index === -1) return { ok: false, error: "Kullanıcı bulunamadı." };

      const updatedEntry: DirectoryEntry = { ...directory[index], ...patch };
      const nextDirectory = [...directory];
      nextDirectory[index] = updatedEntry;
      writeDirectory(nextDirectory);
      setUser(toPublicUser(updatedEntry));
      return { ok: true };
    },
    [user]
  );

  const changePassword = useCallback(
    async (input: PasswordChangeInput): Promise<AuthResult> => {
      if (!user) return { ok: false, error: "Bu işlem için giriş yapmalısınız." };
      if (!isValidPassword(input.yeniSifre)) return { ok: false, error: "Yeni şifre en az 8 karakter olmalı." };
      if (input.yeniSifre !== input.yeniSifreTekrar) return { ok: false, error: "Yeni şifreler eşleşmiyor." };

      const directory = readDirectory();
      const index = directory.findIndex((u) => u.id === user.id);
      if (index === -1) return { ok: false, error: "Kullanıcı bulunamadı." };

      const currentHash = await hashPassword(input.mevcutSifre);
      if (currentHash !== directory[index].passwordHash) {
        return { ok: false, error: "Mevcut şifreniz hatalı." };
      }

      const nextHash = await hashPassword(input.yeniSifre);
      const nextDirectory = [...directory];
      nextDirectory[index] = { ...directory[index], passwordHash: nextHash };
      writeDirectory(nextDirectory);
      return { ok: true };
    },
    [user]
  );

  const identifierExists = useCallback((identifier: string) => {
    const trimmed = identifier.trim().toLowerCase();
    if (!trimmed) return false;
    const normalizedIdentifier = normalizePhone(identifier);
    return readDirectory().some(
      (u) => u.email.toLowerCase() === trimmed || normalizePhone(u.telefon) === normalizedIdentifier
    );
  }, []);

  const resetPassword = useCallback(async (input: PasswordResetInput): Promise<AuthResult> => {
    if (!isValidPassword(input.yeniSifre)) return { ok: false, error: "Yeni şifre en az 8 karakter olmalı." };
    if (input.yeniSifre !== input.yeniSifreTekrar) return { ok: false, error: "Şifreler eşleşmiyor." };

    const directory = readDirectory();
    const identifier = input.identifier.trim().toLowerCase();
    const normalizedIdentifier = normalizePhone(input.identifier);
    const index = directory.findIndex(
      (u) => u.email.toLowerCase() === identifier || normalizePhone(u.telefon) === normalizedIdentifier
    );
    if (index === -1) return { ok: false, error: "Bu bilgilerle eşleşen bir hesap bulunamadı." };

    const nextHash = await hashPassword(input.yeniSifre);
    const nextDirectory = [...directory];
    nextDirectory[index] = { ...directory[index], passwordHash: nextHash };
    writeDirectory(nextDirectory);
    return { ok: true };
  }, []);

  const value = useMemo(
    () => ({
      user,
      isAuthenticated: Boolean(user),
      isLoading,
      register,
      login,
      logout,
      updateProfile,
      changePassword,
      identifierExists,
      resetPassword,
    }),
    [
      user,
      isLoading,
      register,
      login,
      logout,
      updateProfile,
      changePassword,
      identifierExists,
      resetPassword,
    ]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth, AuthProvider içinde kullanılmalıdır.");
  return ctx;
}
