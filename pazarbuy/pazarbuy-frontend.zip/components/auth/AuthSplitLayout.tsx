import type { ReactNode } from "react";
import { ShieldCheck, Package, RotateCcw, Sparkles } from "lucide-react";

const advantages = [
  { icon: ShieldCheck, title: "Güvenli Alışveriş", description: "Alıcı Güvencesi ile korumalı ödeme." },
  { icon: Package, title: "Binlerce Ürün", description: "Yüzlerce satıcıdan geniş ürün yelpazesi." },
  { icon: RotateCcw, title: "Kolay İade", description: "Seçili ürünlerde ücretsiz iade imkânı." },
  { icon: Sparkles, title: "AI Destekli Keşif", description: "İhtiyacına en uygun ürünü AI bulur." },
];

/**
 * Auth ekranlarının (giriş/üye ol/şifremi unuttum/doğrulama) ortak premium
 * split-screen iskeleti. Masaüstünde sol tarafta marka avantajları, sağ
 * tarafta form kartı; mobilde sadece form ön planda.
 */
export function AuthSplitLayout({
  eyebrow,
  title,
  subtitle,
  children,
  footer,
  maxWidthClassName = "max-w-md",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  maxWidthClassName?: string;
}) {
  return (
    <div className="grid grid-cols-1 overflow-hidden rounded-3xl border border-navy-100/80 bg-white shadow-card lg:grid-cols-2">
      <div className="relative hidden flex-col justify-between overflow-hidden bg-gradient-to-br from-navy-900 via-navy-800 to-navy-950 p-10 text-white lg:flex">
        <div
          className="pointer-events-none absolute -left-16 -top-16 h-64 w-64 rounded-full bg-brand-500/25 blur-3xl"
          aria-hidden
        />
        <div
          className="pointer-events-none absolute -bottom-20 -right-10 h-72 w-72 rounded-full bg-brand-500/15 blur-3xl"
          aria-hidden
        />

        <div className="relative">
          <span className="text-2xl font-extrabold">
            Pazar<span className="text-brand-500">Buy</span>
          </span>
          <p className="mt-4 max-w-xs text-balance text-lg font-semibold leading-snug text-white/90">
            Ne istediğini söylersin, ürün seni bulur.
          </p>
        </div>

        <div className="relative flex flex-col gap-5">
          {advantages.map((item) => (
            <div key={item.title} className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/10 text-brand-300 ring-1 ring-white/10">
                <item.icon size={18} />
              </span>
              <div>
                <p className="text-sm font-bold text-white">{item.title}</p>
                <p className="mt-0.5 text-xs text-white/60">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        <p className="relative text-[11px] text-white/40">
          © {new Date().getFullYear()} PazarBuy. Tüm hakları saklıdır.
        </p>
      </div>

      <div className="flex flex-col justify-center p-6 sm:p-10">
        <div className={`mx-auto w-full ${maxWidthClassName}`}>
          {eyebrow ? (
            <span className="inline-flex items-center rounded-full bg-brand-50 px-3 py-1 text-[11px] font-bold uppercase tracking-wide text-brand-600">
              {eyebrow}
            </span>
          ) : null}
          <h1 className="mt-3 text-xl font-extrabold text-navy-900 sm:text-2xl">{title}</h1>
          {subtitle ? <p className="mt-1.5 text-sm text-navy-400">{subtitle}</p> : null}

          <div className="mt-6">{children}</div>

          {footer ? <div className="mt-6">{footer}</div> : null}
        </div>
      </div>
    </div>
  );
}
