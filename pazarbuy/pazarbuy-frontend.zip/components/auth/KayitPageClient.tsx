"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { UserPlus, AlertCircle } from "lucide-react";
import { AuthSplitLayout } from "@/components/auth/AuthSplitLayout";
import { PasswordField } from "@/components/auth/PasswordField";
import { SocialLoginButtons } from "@/components/auth/SocialLoginButtons";
import { TextField, CheckboxRow } from "@/components/seller-application/fields";
import { useAuth } from "@/components/auth/AuthProvider";
import { formatPhoneInput } from "@/lib/auth";

export function KayitPageClient() {
  const { register } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "";

  const [ad, setAd] = useState("");
  const [soyad, setSoyad] = useState("");
  const [email, setEmail] = useState("");
  const [telefon, setTelefon] = useState("");
  const [sifre, setSifre] = useState("");
  const [sifreTekrar, setSifreTekrar] = useState("");
  const [sozlesme, setSozlesme] = useState(false);
  const [kvkk, setKvkk] = useState(false);
  const [ticariIleti, setTicariIleti] = useState(false);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function validate(): Record<string, string> {
    const next: Record<string, string> = {};
    if (!ad.trim()) next.ad = "Ad zorunludur.";
    if (!soyad.trim()) next.soyad = "Soyad zorunludur.";
    if (!email.trim()) next.email = "E-posta zorunludur.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) next.email = "Geçerli bir e-posta adresi girin.";
    if (!telefon.trim()) next.telefon = "Telefon zorunludur.";
    else if (telefon.replace(/\D/g, "").length < 10) next.telefon = "Geçerli bir telefon numarası girin.";
    if (!sifre) next.sifre = "Şifre zorunludur.";
    else if (sifre.length < 8) next.sifre = "Şifre en az 8 karakter olmalı.";
    if (!sifreTekrar) next.sifreTekrar = "Şifre tekrarı zorunludur.";
    else if (sifre !== sifreTekrar) next.sifreTekrar = "Şifreler eşleşmiyor.";
    if (!sozlesme) next.sozlesme = "Üyelik sözleşmesini onaylamalısınız.";
    if (!kvkk) next.kvkk = "KVKK metnini onaylamalısınız.";
    return next;
  }

  async function handleSubmit() {
    setFormError(null);
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    setSubmitting(true);
    const result = await register({
      ad,
      soyad,
      email,
      telefon,
      sifre,
      sifreTekrar,
      uyelikSozlesmesiKabul: sozlesme,
      kvkkKabul: kvkk,
      ticariIletiKabul: ticariIleti,
    });
    setSubmitting(false);

    if (!result.ok) {
      setFormError(result.error);
      return;
    }

    const query = redirectTo ? `?redirect=${encodeURIComponent(redirectTo)}` : "";
    router.push(`/dogrulama${query}`);
  }

  return (
    <AuthSplitLayout
      eyebrow="Üye Ol"
      title="Hemen Üye Ol"
      subtitle="Saniyeler içinde hesabını oluştur, alışverişe başla."
    >
      <div className="flex flex-col gap-4">
        <SocialLoginButtons />

        <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-wide text-navy-300">
          <span className="h-px flex-1 bg-navy-100" />
          veya
          <span className="h-px flex-1 bg-navy-100" />
        </div>

        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2">
          <TextField
            id="ad"
            label="Ad"
            required
            value={ad}
            error={errors.ad}
            onChange={(e) => setAd(e.target.value)}
            placeholder="Adınız"
          />
          <TextField
            id="soyad"
            label="Soyad"
            required
            value={soyad}
            error={errors.soyad}
            onChange={(e) => setSoyad(e.target.value)}
            placeholder="Soyadınız"
          />
        </div>

        <TextField
          id="email"
          label="E-posta"
          type="email"
          required
          value={email}
          error={errors.email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="ornek@eposta.com"
        />

        <TextField
          id="telefon"
          label="Telefon"
          type="tel"
          required
          value={telefon}
          error={errors.telefon}
          onChange={(e) => setTelefon(formatPhoneInput(e.target.value))}
          placeholder="05xx xxx xx xx"
        />

        <PasswordField
          id="sifre"
          label="Şifre"
          required
          value={sifre}
          error={errors.sifre}
          onChange={setSifre}
          placeholder="En az 8 karakter"
          hint="Büyük/küçük harf ve rakam içermesi önerilir."
          showStrength
          autoComplete="new-password"
        />
        <PasswordField
          id="sifreTekrar"
          label="Şifre Tekrar"
          required
          value={sifreTekrar}
          error={errors.sifreTekrar}
          onChange={setSifreTekrar}
          placeholder="Şifrenizi tekrar girin"
          autoComplete="new-password"
        />

        <div className="flex flex-col gap-2.5">
          <CheckboxRow
            id="sozlesme"
            required
            checked={sozlesme}
            onChange={setSozlesme}
            error={errors.sozlesme}
            label="Üyelik sözleşmesini okudum ve kabul ediyorum."
          />
          <CheckboxRow
            id="kvkk"
            required
            checked={kvkk}
            onChange={setKvkk}
            error={errors.kvkk}
            label="KVKK / Aydınlatma Metnini okudum."
          />
          <CheckboxRow
            id="ticariIleti"
            checked={ticariIleti}
            onChange={setTicariIleti}
            label="Kampanya ve fırsatlardan haberdar olmak istiyorum."
          />
        </div>

        {formError ? (
          <p className="flex items-center gap-1.5 rounded-lg bg-rose-50 px-3 py-2.5 text-xs font-medium text-rose-600">
            <AlertCircle size={14} className="shrink-0" />
            {formError}
          </p>
        ) : null}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600 disabled:opacity-60"
        >
          <UserPlus size={16} />
          {submitting ? "Hesap oluşturuluyor…" : "Üye Ol"}
        </button>
      </div>

      <p className="mt-5 text-center text-xs text-navy-400">
        Zaten hesabın var mı?{" "}
        <Link
          href={redirectTo ? `/giris?redirect=${encodeURIComponent(redirectTo)}` : "/giris"}
          className="font-semibold text-brand-600 hover:text-brand-700"
        >
          Giriş Yap
        </Link>
      </p>
    </AuthSplitLayout>
  );
}
