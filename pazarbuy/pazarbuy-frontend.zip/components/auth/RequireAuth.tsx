"use client";

import { useEffect, type ReactNode } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuth } from "@/components/auth/AuthProvider";

/**
 * Sadece giriş yapmış kullanıcıların görebileceği alanları sarmalar.
 * Auth durumu localStorage/sessionStorage'da tutulduğu için sadece
 * client'ta bilinir — bu yüzden guard bir Client Component. Hydration
 * bitene kadar (isLoading) hiçbir şey göstermiyoruz ki içerik bir an
 * için "yanıp sönmesin"; hydration bitip kullanıcı giriş yapmamışsa
 * `/giris?redirect=<mevcut sayfa>` adresine yönlendiriyoruz.
 */
export function RequireAuth({ children }: { children: ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.replace(`/giris?redirect=${encodeURIComponent(pathname || "/hesabim")}`);
    }
  }, [isLoading, isAuthenticated, router, pathname]);

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-navy-100 border-t-brand-500" aria-hidden />
      </div>
    );
  }

  return <>{children}</>;
}
