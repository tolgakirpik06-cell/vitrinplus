"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { LogIn, AlertCircle } from "lucide-react";
import { AuthSplitLayout } from "@/components/auth/AuthSplitLayout";
import { PasswordField } from "@/components/auth/PasswordField";
import { SocialLoginButtons } from "@/components/auth/SocialLoginButtons";
import { TextField } from "@/components/seller-application/fields";
import { useAuth } from "@/components/auth/AuthProvider";

export function GirisPageClient() {
  const { login } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/";

  const [identifier, setIdentifier] = useState("");
  const [sifre, setSifre] = useState("");
  const [beniHatirla, setBeniHatirla] = useState(true);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit() {
    setFormError(null);
    const next: Record<string, string> = {};
    if (!identifier.trim()) next.identifier = "E-posta veya telefon girin.";
    if (!sifre) next.sifre = "Şifre girin.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setSubmitting(true);
    const result = await login({ identifier, sifre, beniHatirla });
    setSubmitting(false);

    if (!result.ok) {
      setFormError(result.error);
      return;
    }

    router.push(redirectTo);
  }

  return (
    <AuthSplitLayout eyebrow="Giriş Yap" title="Hesabına Giriş Yap" subtitle="Fırsatları kaçırma, siparişlerini takip et.">
      <div className="flex flex-col gap-4">
        <SocialLoginButtons />

        <div className="flex items-center gap-3 text-[11px] font-semibold uppercase tracking-wide text-navy-300">
          <span className="h-px flex-1 bg-navy-100" />
          veya
          <span className="h-px flex-1 bg-navy-100" />
        </div>

        <TextField
          id="identifier"
          label="E-posta veya Telefon"
          required
          value={identifier}
          error={errors.identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          placeholder="ornek@eposta.com veya 05xx xxx xx xx"
          onKeyDown={(e) => {
            if (e.key === "Enter") handleSubmit();
          }}
        />

        <PasswordField
          id="sifre"
          label="Şifre"
          required
          value={sifre}
          error={errors.sifre}
          onChange={setSifre}
          placeholder="••••••••"
          autoComplete="current-password"
        />

        <div className="flex items-center justify-between gap-2">
          <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-navy-600">
            <input
              type="checkbox"
              checked={beniHatirla}
              onChange={(e) => setBeniHatirla(e.target.checked)}
              className="h-4 w-4 rounded border-navy-300 text-brand-500 focus:ring-brand-400"
            />
            Beni hatırla
          </label>
          <Link href="/sifremi-unuttum" className="text-xs font-semibold text-brand-600 hover:text-brand-700">
            Şifremi unuttum
          </Link>
        </div>

        {formError ? (
          <p className="flex items-center gap-1.5 rounded-lg bg-rose-50 px-3 py-2.5 text-xs font-medium text-rose-600">
            <AlertCircle size={14} className="shrink-0" />
            {formError}
          </p>
        ) : null}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600 disabled:opacity-60"
        >
          <LogIn size={16} />
          {submitting ? "Giriş yapılıyor…" : "Giriş Yap"}
        </button>
      </div>

      <p className="mt-5 text-center text-xs text-navy-400">
        PazarBuy&apos;da yeni misin?{" "}
        <Link
          href={redirectTo !== "/" ? `/uye-ol?redirect=${encodeURIComponent(redirectTo)}` : "/uye-ol"}
          className="font-semibold text-brand-600 hover:text-brand-700"
        >
          Üye Ol
        </Link>
      </p>
    </AuthSplitLayout>
  );
}
