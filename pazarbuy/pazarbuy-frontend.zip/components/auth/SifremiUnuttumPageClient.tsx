"use client";

import { useState } from "react";
import Link from "next/link";
import { AlertCircle, CheckCircle2, Info, KeyRound } from "lucide-react";
import { AuthSplitLayout } from "@/components/auth/AuthSplitLayout";
import { PasswordField } from "@/components/auth/PasswordField";
import { Stepper } from "@/components/seller-application/Stepper";
import { TextField } from "@/components/seller-application/fields";
import { useAuth } from "@/components/auth/AuthProvider";
import { cn } from "@/lib/utils";

const STEPS = [
  { id: "kimlik", label: "Hesap" },
  { id: "kod", label: "Doğrulama" },
  { id: "sifre", label: "Yeni Şifre" },
  { id: "tamam", label: "Tamamlandı" },
];

const DEMO_CODE = "123456";

export function SifremiUnuttumPageClient() {
  const { identifierExists, resetPassword } = useAuth();
  const [stepIndex, setStepIndex] = useState(0);

  const [identifier, setIdentifier] = useState("");
  const [identifierError, setIdentifierError] = useState<string | null>(null);

  const [code, setCode] = useState("");
  const [codeError, setCodeError] = useState<string | null>(null);

  const [yeniSifre, setYeniSifre] = useState("");
  const [yeniSifreTekrar, setYeniSifreTekrar] = useState("");
  const [passwordErrors, setPasswordErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function handleIdentifierSubmit() {
    if (!identifier.trim()) {
      setIdentifierError("E-posta veya telefon girin.");
      return;
    }
    if (!identifierExists(identifier)) {
      setIdentifierError("Bu bilgilerle eşleşen bir hesap bulunamadı.");
      return;
    }
    setIdentifierError(null);
    setStepIndex(1);
  }

  function handleCodeSubmit() {
    if (code.trim() !== DEMO_CODE) {
      setCodeError("Girdiğiniz kod hatalı, tekrar deneyin.");
      return;
    }
    setCodeError(null);
    setStepIndex(2);
  }

  async function handlePasswordSubmit() {
    const errors: Record<string, string> = {};
    if (!yeniSifre || yeniSifre.length < 8) errors.yeniSifre = "Şifre en az 8 karakter olmalı.";
    if (yeniSifre !== yeniSifreTekrar) errors.yeniSifreTekrar = "Şifreler eşleşmiyor.";
    setPasswordErrors(errors);
    if (Object.keys(errors).length > 0) return;

    setSubmitting(true);
    setSubmitError(null);
    const result = await resetPassword({ identifier, yeniSifre, yeniSifreTekrar });
    setSubmitting(false);

    if (!result.ok) {
      setSubmitError(result.error);
      return;
    }
    setStepIndex(3);
  }

  return (
    <AuthSplitLayout eyebrow="Şifremi Unuttum" title="Şifreni Sıfırla" maxWidthClassName="max-w-md">
      <div className="mb-6">
        <Stepper steps={STEPS} currentIndex={stepIndex} />
      </div>

      {stepIndex === 0 ? (
        <div className="flex flex-col gap-4">
          <p className="text-sm text-navy-500">
            Hesabına kayıtlı e-posta adresini veya telefon numaranı gir.
          </p>
          <TextField
            id="identifier"
            label="E-posta veya Telefon"
            required
            value={identifier}
            error={identifierError ?? undefined}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="ornek@eposta.com veya 05xx xxx xx xx"
          />
          <button
            type="button"
            onClick={handleIdentifierSubmit}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600"
          >
            Devam Et
          </button>
        </div>
      ) : null}

      {stepIndex === 1 ? (
        <div className="flex flex-col gap-4">
          <p className="flex items-start gap-2.5 rounded-xl border border-navy-100 bg-navy-50/50 px-4 py-3 text-xs leading-relaxed text-navy-500">
            <Info size={15} className="mt-0.5 shrink-0 text-navy-400" />
            Bu demo sürümünde gerçek bir kod gönderilmiyor. Devam etmek için{" "}
            <span className="font-semibold text-navy-700">{DEMO_CODE}</span> kodunu girebilirsin.
          </p>
          <TextField
            id="code"
            label="Doğrulama Kodu"
            required
            inputMode="numeric"
            maxLength={6}
            value={code}
            error={codeError ?? undefined}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
            placeholder="6 haneli kod"
          />
          <button
            type="button"
            onClick={handleCodeSubmit}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600"
          >
            Kodu Doğrula
          </button>
        </div>
      ) : null}

      {stepIndex === 2 ? (
        <div className="flex flex-col gap-4">
          <PasswordField
            id="yeniSifre"
            label="Yeni Şifre"
            required
            value={yeniSifre}
            error={passwordErrors.yeniSifre}
            onChange={setYeniSifre}
            placeholder="En az 8 karakter"
            showStrength
            autoComplete="new-password"
          />
          <PasswordField
            id="yeniSifreTekrar"
            label="Yeni Şifre Tekrar"
            required
            value={yeniSifreTekrar}
            error={passwordErrors.yeniSifreTekrar}
            onChange={setYeniSifreTekrar}
            placeholder="Şifrenizi tekrar girin"
            autoComplete="new-password"
          />

          {submitError ? (
            <p className="flex items-center gap-1.5 rounded-lg bg-rose-50 px-3 py-2.5 text-xs font-medium text-rose-600">
              <AlertCircle size={14} className="shrink-0" />
              {submitError}
            </p>
          ) : null}

          <button
            type="button"
            onClick={handlePasswordSubmit}
            disabled={submitting}
            className={cn(
              "flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600",
              submitting && "opacity-60"
            )}
          >
            <KeyRound size={16} />
            {submitting ? "Kaydediliyor…" : "Şifreyi Güncelle"}
          </button>
        </div>
      ) : null}

      {stepIndex === 3 ? (
        <div className="flex flex-col items-center gap-4 py-2 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-500">
            <CheckCircle2 size={28} />
          </span>
          <p className="text-sm text-navy-500">Şifren başarıyla güncellendi. Yeni şifrenle giriş yapabilirsin.</p>
          <Link
            href="/giris"
            className="mt-1 flex w-full items-center justify-center gap-2 rounded-full bg-brand-500 px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_24px_-10px_rgba(255,106,18,0.55)] transition-colors hover:bg-brand-600"
          >
            Giriş Yap
          </Link>
        </div>
      ) : null}
    </AuthSplitLayout>
  );
}
