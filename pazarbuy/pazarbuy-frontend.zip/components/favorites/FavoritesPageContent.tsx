"use client";

import Link from "next/link";
import { Heart, ShoppingCart, Trash2 } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { useFavorites } from "@/components/favorites/FavoritesProvider";
import { useCart } from "@/components/cart/CartProvider";
import { getProductBySlug } from "@/lib/mock-catalog";
import { formatPrice } from "@/lib/utils";

/**
 * /favoriler (üst düzey hızlı erişim) ve /hesabim/favorilerim (hesap paneli)
 * AYNI bileşeni kullanır — favoriler tek bir yerde (FavoritesProvider) tutulur,
 * iki farklı sayfa aynı gerçek veriyi gösterir; kopya kod/liste yok.
 */
export function FavoritesPageContent() {
  const { user } = useAuth();
  const { slugs, removeFavorite } = useFavorites();
  const { addItem } = useCart();

  const resolved = slugs
    .map((slug) => ({ slug, product: getProductBySlug(slug) }))
    .filter((x) => Boolean(x.product));

  if (!user) return null;

  if (resolved.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-navy-100/80 bg-white px-6 py-14 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-400">
          <Heart size={24} />
        </span>
        <p className="text-sm font-semibold text-navy-800">Henüz favori ürünün yok</p>
        <p className="max-w-xs text-xs text-navy-400">
          Beğendiğin ürünlerdeki kalp ikonuna tıklayarak onları favorilerine ekleyebilirsin.
        </p>
        <Link
          href="/"
          className="mt-1 rounded-full bg-brand-500 px-4 py-2 text-xs font-semibold text-white hover:bg-brand-600"
        >
          Alışverişe Başla
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {resolved.map(({ slug, product }) =>
        product ? (
          <div
            key={slug}
            className="flex items-center gap-3 rounded-2xl border border-navy-100/80 bg-white p-3.5 sm:p-4"
          >
            <Link
              href={`/urun/${product.slug}`}
              className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-navy-50/60 p-2 sm:h-20 sm:w-20"
            >
              <span className="text-[10px] text-navy-300">Ürün Görseli</span>
            </Link>

            <div className="min-w-0 flex-1">
              <Link
                href={`/urun/${product.slug}`}
                className="line-clamp-2 text-sm font-semibold text-navy-800 hover:text-brand-600"
              >
                {product.name}
              </Link>
              <p className="mt-0.5 truncate text-xs text-navy-400">{product.seller}</p>
              <p className="mt-1 text-base font-extrabold text-navy-900">{formatPrice(product.price)}</p>
            </div>

            <div className="flex shrink-0 flex-col items-end gap-2">
              <button
                type="button"
                onClick={() => addItem({ slug: product.slug })}
                className="flex items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100"
              >
                <ShoppingCart size={13} />
                <span className="hidden sm:inline">Sepete Ekle</span>
              </button>
              <button
                type="button"
                onClick={() => removeFavorite(slug)}
                className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium text-navy-400 hover:bg-rose-50 hover:text-rose-600"
              >
                <Trash2 size={13} />
                <span className="hidden sm:inline">Favoriden Çıkar</span>
              </button>
            </div>
          </div>
        ) : null
      )}
    </div>
  );
}
