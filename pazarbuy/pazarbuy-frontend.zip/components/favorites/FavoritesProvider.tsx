"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { useAuth } from "@/components/auth/AuthProvider";

/**
 * Favoriler SADECE giriş yapmış kullanıcılar için tutulur (misafir
 * kullanıcı kalp butonuna basınca /giris'e yönlendirilir — bkz.
 * FavoriteButton.tsx). Her kullanıcının favori listesi ayrı bir
 * localStorage anahtarında tutulur (`pazarbuy-favorites:<userId>`) —
 * böylece aynı tarayıcıda birden fazla demo hesabı denenirse favoriler
 * birbirine karışmaz.
 */

type FavoritesContextValue = {
  slugs: string[];
  isFavorite: (slug: string) => boolean;
  toggleFavorite: (slug: string) => void;
  removeFavorite: (slug: string) => void;
};

const FavoritesContext = createContext<FavoritesContextValue | null>(null);

function storageKey(userId: string) {
  return `pazarbuy-favorites:${userId}`;
}

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [slugs, setSlugs] = useState<string[]>([]);

  useEffect(() => {
    if (!user) {
      setSlugs([]);
      return;
    }
    try {
      const raw = window.localStorage.getItem(storageKey(user.id));
      const parsed = raw ? (JSON.parse(raw) as string[]) : [];
      setSlugs(Array.isArray(parsed) ? parsed : []);
    } catch {
      setSlugs([]);
    }
  }, [user]);

  useEffect(() => {
    if (!user) return;
    try {
      window.localStorage.setItem(storageKey(user.id), JSON.stringify(slugs));
    } catch {
      // best-effort
    }
  }, [slugs, user]);

  const isFavorite = useCallback((slug: string) => slugs.includes(slug), [slugs]);

  const toggleFavorite = useCallback((slug: string) => {
    setSlugs((prev) => (prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug]));
  }, []);

  const removeFavorite = useCallback((slug: string) => {
    setSlugs((prev) => prev.filter((s) => s !== slug));
  }, []);

  const value = useMemo(
    () => ({ slugs, isFavorite, toggleFavorite, removeFavorite }),
    [slugs, isFavorite, toggleFavorite, removeFavorite]
  );

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error("useFavorites, FavoritesProvider içinde kullanılmalıdır.");
  return ctx;
}
