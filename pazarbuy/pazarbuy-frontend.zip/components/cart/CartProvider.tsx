"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type { CartLine } from "@/types";

const STORAGE_KEY = "pazarbuy-cart";

function buildLineId(slug: string, variantLabel?: string) {
  return variantLabel ? `${slug}::${variantLabel}` : slug;
}

type AddItemInput = {
  slug: string;
  quantity?: number;
  variantLabel?: string;
};

type CartContextValue = {
  lines: CartLine[];
  count: number;
  addItem: (input: AddItemInput) => void;
  removeItem: (lineId: string) => void;
  updateQuantity: (lineId: string, quantity: number) => void;
  clear: () => void;
  mergeLines: (incoming: CartLine[]) => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);

  // localStorage sadece client'ta mevcut olduğu için ilk render'da boş
  // state ile başlıyoruz, gerçek veriyi mount sonrası useEffect'te okuyoruz.
  // Bu sayede sunucu/istemci arasında hydration uyuşmazlığı oluşmaz.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as CartLine[];
        if (Array.isArray(parsed)) setLines(parsed);
      }
    } catch {
      // localStorage okunamazsa sepet boş başlar, uygulama çalışmaya devam eder.
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      // yazma başarısız olsa da uygulama akışı bozulmasın.
    }
  }, [lines, hydrated]);

  const addItem = useCallback(({ slug, quantity = 1, variantLabel }: AddItemInput) => {
    const lineId = buildLineId(slug, variantLabel);
    setLines((prev) => {
      const existing = prev.find((line) => line.lineId === lineId);
      if (existing) {
        return prev.map((line) =>
          line.lineId === lineId ? { ...line, quantity: line.quantity + quantity } : line
        );
      }
      return [...prev, { lineId, slug, quantity, variantLabel }];
    });
  }, []);

  const removeItem = useCallback((lineId: string) => {
    setLines((prev) => prev.filter((line) => line.lineId !== lineId));
  }, []);

  const updateQuantity = useCallback((lineId: string, quantity: number) => {
    setLines((prev) => {
      if (quantity <= 0) return prev.filter((line) => line.lineId !== lineId);
      return prev.map((line) => (line.lineId === lineId ? { ...line, quantity } : line));
    });
  }, []);

  const clear = useCallback(() => setLines([]), []);

  /**
   * Misafir sepetini (localStorage'daki `lines`) gerçek bir backend'den
   * gelecek kullanıcıya-özel sepetle birleştirmek için hazır bir metod.
   * Şu an gerçek bir backend/kullanıcı-sepeti YOK — bu yüzden hiçbir yerden
   * otomatik çağrılmıyor — ama giriş akışına (AuthProvider.login sonrası)
   * bir API'den `mergeLines(sunucudakiSatırlar)` çağrısı eklenecek şekilde
   * mimari hazır: aynı lineId'ye sahip satırların adetleri toplanır, yeni
   * olanlar eklenir; hiçbir satır kaybolmaz.
   */
  const mergeLines = useCallback((incoming: CartLine[]) => {
    setLines((prev) => {
      const next = [...prev];
      for (const line of incoming) {
        const existingIndex = next.findIndex((l) => l.lineId === line.lineId);
        if (existingIndex >= 0) {
          next[existingIndex] = {
            ...next[existingIndex],
            quantity: next[existingIndex].quantity + line.quantity,
          };
        } else {
          next.push(line);
        }
      }
      return next;
    });
  }, []);

  const count = useMemo(() => lines.reduce((sum, line) => sum + line.quantity, 0), [lines]);

  const value = useMemo(
    () => ({ lines, count, addItem, removeItem, updateQuantity, clear, mergeLines }),
    [lines, count, addItem, removeItem, updateQuantity, clear, mergeLines]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart, CartProvider içinde kullanılmalıdır.");
  return ctx;
}
